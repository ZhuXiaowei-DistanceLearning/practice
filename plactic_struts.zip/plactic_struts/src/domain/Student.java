package domain;

import java.io.Serializable;
import java.sql.Date;

public class Student implements Serializable {

	private int sid;
	private String username;
	private String gender;
	private Date birthday;
	private String major;
	private String note;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", username=" + username + ", gender=" + gender + ", birthday=" + birthday
				+ ", major=" + major + ", note=" + note + "]";
	}

}
