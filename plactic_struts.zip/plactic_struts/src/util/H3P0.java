package util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class H3P0 {
	private static SessionFactory factory;

	static {
		Configuration conf = new Configuration().configure();
		factory = conf.buildSessionFactory();
	}

	public static Session openSession() {
		return factory.openSession();
	}

	public static Session getCurrentSession() {
		return factory.getCurrentSession();
	}
}
