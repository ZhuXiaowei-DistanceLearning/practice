package StudentDaoImpl;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import StudentDao.StudentDao;
import domain.Student;
import domain.Teacher;
import util.H3P0;

public class StudentDaoImpl implements StudentDao {

	public void register(Student student) {
		Session session = H3P0.getCurrentSession();
		session.save(student);
	}

	public Teacher login(String username, String password) {
		Session session = H3P0.getCurrentSession();
		Teacher teacher = null;
		String hql = "from Teacher where username = '" + username + "' and password = '" + password + "'";
		List<Teacher> list = session.createQuery(hql).list();
		if (list != null && list.size() > 0) {
			teacher = list.get(0);
		}
		return teacher;
	}

}
