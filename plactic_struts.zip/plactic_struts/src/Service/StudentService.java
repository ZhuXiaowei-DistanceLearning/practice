package Service;

import domain.Student;
import domain.Teacher;

public interface StudentService {
	public void register(Student student);

	public Teacher login(String username, String password);
}
