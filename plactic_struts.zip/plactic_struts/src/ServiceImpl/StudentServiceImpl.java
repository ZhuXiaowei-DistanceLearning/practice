package ServiceImpl;

import Service.StudentService;
import StudentDao.StudentDao;
import StudentDaoImpl.StudentDaoImpl;
import domain.Student;
import domain.Teacher;

public class StudentServiceImpl implements StudentService {
	private StudentDao sd = new StudentDaoImpl();

	@Override
	public void register(Student student) {
		sd.register(student);
	}

	@Override
	public Teacher login(String username, String password) {
		Teacher teacher = sd.login(username, password);
		if (teacher != null) {
			return teacher;
		}
		return null;
	}
}
