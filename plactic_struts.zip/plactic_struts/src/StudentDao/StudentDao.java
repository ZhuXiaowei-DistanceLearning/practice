package StudentDao;

import domain.Student;
import domain.Teacher;

public interface StudentDao {
	public void register(Student student);

	public Teacher login(String username, String password);
}
