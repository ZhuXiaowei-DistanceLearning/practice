package struts;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import Service.StudentService;
import ServiceImpl.StudentServiceImpl;
import domain.Student;
import domain.Teacher;

public class loginAction extends ActionSupport implements ModelDriven<Teacher> {
	private Teacher teacher = new Teacher();
	private StudentService ss = new StudentServiceImpl();

	@Override
	public Teacher getModel() {
		return teacher;
	}

	public String login() {
		ServletActionContext.getContext().put("teacher", teacher);
		Teacher teacher2 = ss.login(teacher.getUsername(), teacher.getPassword());
		if (teacher2 != null) {
			return "success";
		}
		return "error";
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

}