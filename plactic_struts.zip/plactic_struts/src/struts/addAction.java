package struts;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import Service.StudentService;
import ServiceImpl.StudentServiceImpl;
import domain.Student;

public class addAction extends ActionSupport implements ModelDriven<Student> {
	private Student student = new Student();
	private StudentService ss = new StudentServiceImpl();

	@Override
	public Student getModel() {
		return student;
	}

	public String register() {
		ss.register(student);
		return "success";
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

}
