package pagebean;

import java.util.List;

public class PageBean<T> {
	/**
	 * ��Ҫ����: ��ǰҳ ÿҳ��ʾ���� �ܼ�¼��
	 */
	private int pageNum;
	private int pageSize;
	private int totalRecord;

	/**
	 * ���㣺 ��ʼ������ ��ҳ�� �޲ι��췽������
	 */
	private int startIndex;
	private int totalPage;

	// ����
	private List<T> data;

	/**
	 * ��̬��ʾ����
	 */
	private int start;
	private int end;

	public PageBean(int pageNum, int pageSize, int totalRecord) {
		super();
		this.pageNum = pageNum;
		this.pageSize = pageSize;
		this.totalRecord = totalRecord;

		startIndex = (pageNum - 1) * pageSize;
		totalPage = (totalRecord + pageSize - 1) / pageSize;

		// ��̬��ʾ��
		start = 1;
		end = 10;
		if (totalPage < 10) {
			this.end = this.totalPage;
		} else {
			start = pageNum - 4;
			end = pageNum + 5;
			if (start < 1) {
				start = 1;
				end = 10;
			}
			if (end > totalPage) {
				end = totalPage;
				start = totalPage - 9;
			}
		}
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalRecord() {
		return totalRecord;
	}

	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

}
