package user.web.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import user.Dao.UserDao;
import user.Dao.Impl.UserDaoImpl;
import user.Service.UserService;
import user.Service.Impl.UserServiceImpl;
import user.domain.User;

public class userAction extends ActionSupport implements ModelDriven<User> {
	private User user = new User();

	@Override
	public User getModel() {
		return user;
	}

	private UserService userService;

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	/**
	 * ע�����֤��
	 * 
	 * @return
	 */
	public String loginValidator() {
		userService.register(user);
		return "register";
	}

	/**
	 * ��¼
	 * 
	 * @return
	 */
	public String login() {
		User login = userService.login(user);
		if (login != null) {
			ActionContext.getContext().put("login", login);
			return "login";
		}
		this.addFieldError("", "�û������������");
		return "home";
	}

	/**
	 * ���������û�
	 */
	public String findAll() {
		List<User> userfindAll = userService.findAll();
		if (userfindAll != null) {
			ActionContext.getContext().put("userfindAll", userfindAll);
			return "findAll";
		}
		return null;
	}

	/**
	 * ����ID
	 * 
	 * @return
	 */
	public String findId() {
		User findId = userService.findId(user.getId());
		if (findId != null) {
			ActionContext.getContext().getValueStack().push(findId);
			return "findId";
		}
		return null;
	}

	/**
	 * �޸��û�
	 */
	public String editUser() {
		userService.editUser(user);
		return "editUser";
	}

	/**
	 * ɾ���û�
	 */
	public String deleteUser() {
		userService.deleteUser(user);
		return "deleteUser";
	}

	/**
	 * �����û�
	 */
	public String addUser() {
		userService.addUser(user);
		return "addUser";
	}
	
	public String addPage(){
		return "addPage";
	}
}
