package user.Dao.Impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import admin.domain.Admin;
import user.Dao.UserDao;
import user.domain.User;

public class UserDaoImpl extends HibernateDaoSupport implements UserDao {

	@Override
	public void register(User user) {
		this.getHibernateTemplate().save(user);
	}

	@Override
	public User login(String username, String password) {
		List<User> list = this.getHibernateTemplate().find("FROM User WHERE username = ? AND PASSWORD =?", username,
				password);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<User> findAll() {
		return this.getHibernateTemplate().find("from User");
	}

	@Override
	public User findId(String id) {
		List<User> list = this.getHibernateTemplate().find("from User where id = ?", id);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public void eitUser(User user) {
		this.getHibernateTemplate().update(user);
	}

	@Override
	public void deleteUser(User user) {
		this.getHibernateTemplate().delete(user);
	}

	@Override
	public void addUser(User user) {
		this.getHibernateTemplate().saveOrUpdate(user);
	}
}
