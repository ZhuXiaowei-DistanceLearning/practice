package user.domain;

public class User {
	/**
	 * id �û�ID int ���� username �û��˺� varchar(20) �ǿ� password �û����� varchar(20) �ǿ�
	 * name ��ʵ���� varchar(20) �ǿ� nic �û��ǳ� varchar(20) �ǿ� sex �Ա� char(2) �ǿ� age ����
	 * int �� Email �����ʼ� varchar(30) �� phone �绰 varchar(20) �� selfshow ����˵��
	 * varchar(300) ��
	 */
	private String id;
	private String username;
	private String password;
	private String name;
	private String nic;
	private String sex;
	private int age;
	private String Email;
	private String phone;
	private String selfshow;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNic() {
		return nic;
	}

	public void setNic(String nic) {
		this.nic = nic;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSelfshow() {
		return selfshow;
	}

	public void setSelfshow(String selfshow) {
		this.selfshow = selfshow;
	}

}
