package user.Service.Impl;

import java.util.List;

import user.Dao.UserDao;
import user.Service.UserService;
import user.domain.User;

public class UserServiceImpl implements UserService {
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public void register(User user) {
		this.userDao.register(user);
	}

	@Override
	public User login(User user) {
		return this.userDao.login(user.getUsername(),user.getPassword());
	}

	@Override
	public List<User> findAll() {
		return this.userDao.findAll();
	}

	@Override
	public User findId(String id) {
		return this.userDao.findId(id);
	}

	@Override
	public void editUser(User user) {
		this.userDao.eitUser(user);
	}

	@Override
	public void deleteUser(User user) {
		this.userDao.deleteUser(user);
	}

	@Override
	public void addUser(User user) {
		this.userDao.addUser(user);
	}

}
