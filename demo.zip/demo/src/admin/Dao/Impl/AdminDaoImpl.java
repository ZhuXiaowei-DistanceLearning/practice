package admin.Dao.Impl;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import admin.Dao.AdminDao;
import admin.domain.Admin;
import pagebean.PageHibernateCallback;

public class AdminDaoImpl extends HibernateDaoSupport implements AdminDao {

	@Override
	public Admin findUser(String username, String password) {
		List<Admin> list = this.getHibernateTemplate().find("from Admin where username=? and password=?", username,
				password);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<Admin> findAll() {
		return this.getHibernateTemplate().find("from Admin");
	}

	@Override
	public Admin findId(String id) {
		List<Admin> list = this.getHibernateTemplate().find("from Admin where id = ?", id);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public void addOrEdit(Admin admin) {
		this.getHibernateTemplate().saveOrUpdate(admin);
	}

	@Override
	public void deleteUser(Admin admin) {
		this.getHibernateTemplate().delete(admin);
	}

	@Override
	public List<Admin> findAll(String condition, Object[] params) {
		String hql = "from Admin where 1=1" + condition;
		return this.getHibernateTemplate().find(hql, params);
	}

	@Override
	public Admin findUsername(String username) {
		List<Admin> findUsername = this.getHibernateTemplate().find("from Admin where username = ?", username);
		if (findUsername.size() == 1) {
			return findUsername.get(0);
		}
		return null;
	}

	@Override
	public int getTotalRecord(String condition, Object[] params) {
		String hql = "select count(*) from Admin where 1=1 " + condition;
		List<Long> list = this.getHibernateTemplate().find(hql, params);
		return list.get(0).intValue();
	}

	@Override
	public List<Admin> findAll(String condition, Object[] params, int startIndex, int pageSize) {
		String hql = "from Admin where 1=1 " + condition;
		return this.getHibernateTemplate().execute(new PageHibernateCallback<Admin>().setHql(hql).setPageSize(pageSize)
				.setParams(params).setStartIndex(startIndex));
	}

}
