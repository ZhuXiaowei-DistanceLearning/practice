package admin.web.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import admin.Service.AdminService;
import admin.Service.Impl.AdminServiceImpl;
import admin.domain.Admin;
import pagebean.PageBean;

public class adminAction extends ActionSupport implements ModelDriven<Admin> {
	private Admin admin = new Admin();

	@Override
	public Admin getModel() {
		return admin;
	}

	private AdminService adminService;

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	private int pageSize = 2;
	private int pageNum = 1;

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public String login() {
		Admin user = adminService.findUser(admin.getUsername(), admin.getPassword());
		if (user != null) {
			ActionContext.getContext().getSession().put("user", user);
			return "home";
		}
		this.addFieldError("", "�û������������");
		return "login";
	}

	/**
	 * ��¼�ɹ������session
	 * 
	 * @return
	 */
	public String homepage() {
		return "homepage";
	}

	/**
	 * ��ת����ҳ��
	 */
	public String addPage() {
		return "addPage";
	}

	/**
	 * �������й���Ա�û�
	 */
	public String findAll() {
		/*
		 * List<Admin> adminfindAll = adminService.findAll(); if (adminfindAll
		 * != null) { ActionContext.getContext().put("adminfindAll",
		 * adminfindAll); return "findAll"; } return null;
		 */
		/*
		 * List<Admin> findAll = adminService.findAll(admin);
		 * ActionContext.getContext().put("findAll", findAll);
		 */
		PageBean<Admin> findAll = this.adminService.findAll(admin, pageNum, pageSize);
		ActionContext.getContext().put("findAll", findAll);
		return "findAll";
	}

	/**
	 * ɾ���û�
	 */
	public String deleteUser() {
		adminService.deleteUser(admin);
		return "deleteUser";
	}

	/**
	 * ��ʾ�༭������ҳ��,����ID����
	 * 
	 * @return
	 */
	public String addOrEditUI() {
		System.out.println(admin.getId());
		if (StringUtils.isNotBlank(admin.getId())) {
			Admin UI = this.adminService.findId(admin.getId());
			ActionContext.getContext().getValueStack().push(UI);
		}
		return "addOrEditUI";
	}

	/**
	 * �����û����߱༭����Ա
	 */
	public String addOrEdit() {
		adminService.addOrEdit(admin);
		return "addOrEdit";
	}

	/*
	 * ��֤�û����Ƿ����
	 */

	public String findUsername() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		Admin findUsername = adminService.findUsername(admin);
		if (findUsername != null) {
			response.getWriter().print(true);
		} else {
			response.getWriter().print(false);
		}
		return NONE;
	}
}
