package admin.Service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import admin.Dao.AdminDao;
import admin.Service.AdminService;
import admin.domain.Admin;
import pagebean.PageBean;

public class AdminServiceImpl implements AdminService {
	private AdminDao adminDao;

	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	@Override
	public Admin findUser(String username, String password) {
		return this.adminDao.findUser(username, password);
	}

	@Override
	public List<Admin> findAll() {
		return this.adminDao.findAll();
	}

	@Override
	public Admin findId(String id) {
		return this.adminDao.findId(id);
	}

	@Override
	public void addOrEdit(Admin admin) {
		this.adminDao.addOrEdit(admin);
	}

	@Override
	public void deleteUser(Admin admin) {
		this.adminDao.deleteUser(admin);
	}

	@Override
	public List<Admin> findAll(Admin admin) {
		StringBuilder build = new StringBuilder();
		List<Object> list = new ArrayList<Object>();
		if (StringUtils.isNotBlank(admin.getId())) {
			build.append(" and id like ?");
			list.add("%" + admin.getId() + "%");
		}
		if (StringUtils.isNotBlank(admin.getName())) {
			build.append(" and name like ?");
			list.add("%" + admin.getName() + "%");
		}
		String condition = build.toString();
		Object[] params = list.toArray();
		return adminDao.findAll(condition, params);
	}

	@Override
	public Admin findUsername(Admin admin) {
		return this.adminDao.findUsername(admin.getUsername());
	}

	@Override
	public PageBean<Admin> findAll(Admin admin, int pageNum, int pageSize) {
		StringBuilder build = new StringBuilder();
		List<Object> list = new ArrayList<Object>();
		if (StringUtils.isNotBlank(admin.getId())) {
			build.append(" and id like ?");
			list.add("%" + admin.getId() + "%");
		}
		if (StringUtils.isNotBlank(admin.getName())) {
			build.append(" and name like ?");
			list.add("%" + admin.getName() + "%");
		}
		String condition = build.toString();
		Object[] params = list.toArray();
		int totalRecord = this.adminDao.getTotalRecord(condition, params);
		PageBean<Admin> pagebean = new PageBean<Admin>(pageNum, pageSize, totalRecord);
		List<Admin> data = this.adminDao.findAll(condition, params, pagebean.getStartIndex(), pagebean.getPageSize());
		pagebean.setData(data);
		return pagebean;
	}

}
