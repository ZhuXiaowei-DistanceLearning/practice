package cn.hshx.mapper;

import cn.hshx.pojo.TMenuTable;
import cn.hshx.pojo.TMenuTableExample;
import cn.hshx.pojo.TMenuTableKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TMenuTableMapper {
    int countByExample(TMenuTableExample example);

    int deleteByExample(TMenuTableExample example);

    int deleteByPrimaryKey(TMenuTableKey key);

    int insert(TMenuTable record);

    int insertSelective(TMenuTable record);

    List<TMenuTable> selectByExample(TMenuTableExample example);

    TMenuTable selectByPrimaryKey(TMenuTableKey key);

    int updateByExampleSelective(@Param("record") TMenuTable record, @Param("example") TMenuTableExample example);

    int updateByExample(@Param("record") TMenuTable record, @Param("example") TMenuTableExample example);

    int updateByPrimaryKeySelective(TMenuTable record);

    int updateByPrimaryKey(TMenuTable record);
}