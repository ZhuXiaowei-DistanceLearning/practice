package cn.hshx.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hshx.pojo.Menu;
import cn.hshx.service.MenuService;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

@Controller
@RequestMapping("/menu")
public class MenuAction {
	@Autowired
	private MenuService menuService;

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult PageQuery(int page, int rows) {
		EasyUIDataGridResult result = menuService.pageQuery(page, rows);
		return result;
	}

	/**
	 * 增加学院
	 *
	 * @return
	 */
	@RequestMapping("addMenu")
	public String addMenu(Menu model) {
		menuService.save(model);
		return "/base/menu";
	}

	/**
	 * ɾ��
	 *
	 * @return
	 */
	@RequestMapping("deleteMenu")
	@ResponseBody
	public E3Result delete(String ids) {
		E3Result result = menuService.delete(ids);
		return result;
	}

	/**
	 * 修改菜品
	 *
	 * @return
	 */
	@RequestMapping("editMenu")
	public String editMenu(Menu model) {
		menuService.edit(model);
		return "/base/menu";
	}

	/**
	 * 查询列表
	 */
	@RequestMapping("listajax")
	@ResponseBody
	public String listajax(HttpServletResponse response) throws IOException {
		List<Menu> list = menuService.findAll();
		String[] excludes = {};
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setExcludes(excludes);
		JSONArray jsonObject = JSONArray.fromObject(list, jsonConfig);
		String json = jsonObject.toString();
		response.setContentType("text/json;charset=utf-8");
		response.getWriter().print(json);
		return null;
	}

	@RequestMapping("/page")
	public String page() {
		return "/base/menu";
	}
}
