package cn.hshx.controller;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hshx.pojo.Menu;
import cn.hshx.pojo.User;
import cn.hshx.service.UserService;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

@Controller
@RequestMapping("/user")
public class UserAction {
	@Autowired
	private UserService userService;

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult PageQuery(int page, int rows) {
		EasyUIDataGridResult result = userService.pageQuery(page, rows);
		return result;
	}

	/**
	 * 增加学院
	 *
	 * @return
	 */
	@RequestMapping("addUser")
	public String addUser(User model) {
		model.setBegintime(new Date());
		userService.save(model);
		return "/base/user";
	}

	/**
	 * ɾ��
	 *
	 * @return
	 */
	@RequestMapping("deleteUser")
	@ResponseBody
	public E3Result delete(String ids) {
		E3Result result = userService.delete(ids);
		return result;
	}

	/**
	 * 修改菜品
	 *
	 * @return
	 */
	@RequestMapping("editUser")
	public String editUser(User model,HttpSession session) {
		User user = (User) session.getAttribute("user");
		model.setBegintime(user.getBegintime());
		userService.edit(model);
		return "/base/user";
	}
}
