package cn.hshx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hshx.pojo.TMenuTable;
import cn.hshx.service.TMenuTableService;
import pojo.EasyUIDataGridResult;

@Controller
@RequestMapping("/menutable")
public class TMenuTableAction {
	@Autowired
	private TMenuTableService tMenuTableService;

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult pageQuery(int rows, int page) {
		EasyUIDataGridResult result = tMenuTableService.pageQuery(page, rows);
		return result;
	}
	
	@RequestMapping("/money")
	public String pay(TMenuTable model){
		tMenuTableService.pay(model);
		return "/base/money";
	}
}
