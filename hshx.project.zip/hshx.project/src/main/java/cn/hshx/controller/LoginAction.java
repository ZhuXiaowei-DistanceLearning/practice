package cn.hshx.controller;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hshx.pojo.User;
import cn.hshx.service.LoginService;
import utils.CookieUtils;
import utils.E3Result;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
public class LoginAction {

	@Autowired
	private LoginService loginService;

	@RequestMapping("/home.action")
	public String login(String username, String password, String checkcode, HttpSession session,
			HttpServletResponse response) {
		String key = (String) session.getAttribute("key");
		if (StringUtils.isNotBlank(checkcode) && checkcode.equals(key)) {
			User user = loginService.login(username, password);
			if (user == null) {
				return "/login";
			} else {
				session.setAttribute("user", user);
				return "/common/index";
			}
		}
		return "/login";
	}

	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "/login";
	}
}
