package cn.hshx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hshx.pojo.Desk;
import cn.hshx.pojo.TMenuTable;
import cn.hshx.service.TableService;
import pojo.EasyUIDataGridResult;

@Controller
@RequestMapping("/table")
public class TableAction {
	@Autowired
	private TableService tableService;

	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult PageQuery(int page, int rows) {
		EasyUIDataGridResult result = tableService.pageQuery(page, rows);
		return result;
	}

	@RequestMapping("/addDesk")
	public String addDesk(Desk model) {
		tableService.edit(model);
		return "/base/menu";
	}

	@RequestMapping("/addMenu")
	public String addMenu(String mid, String tid, String money) {
		tableService.money(mid, tid, money);
		return "/base/table";

	}
}
