package cn.hshx.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TMenuTable extends TMenuTableKey {
	private Integer money;

	private Date begintime;

	private Date endtime;

	public String getFormatDate() {
		if (begintime != null) {
			return new SimpleDateFormat("yyyy-MM-dd").format(begintime);
		} else {
			return "未提交";
		}
	}

	public String getEndDate() {
		if (endtime != null) {
			return new SimpleDateFormat("yyyy-MM-dd").format(endtime);
		} else {
			return "用餐中";
		}
	}

	public Integer getMoney() {
		return money;
	}

	public void setMoney(Integer money) {
		this.money = money;
	}

	public Date getBegintime() {
		return begintime;
	}

	public void setBegintime(Date begintime) {
		this.begintime = begintime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}
}