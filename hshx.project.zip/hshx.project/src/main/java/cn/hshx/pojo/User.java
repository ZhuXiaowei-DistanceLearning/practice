package cn.hshx.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class User {
	private String id;

	private String name;

	private String password;

	private Integer age;

	private String qx;

	private String sex;

	private String status;

	private Date begintime;

	private Double salary;

	public String getFormatDate() {
		if (begintime != null) {
			return new SimpleDateFormat("yyyy-MM-dd").format(begintime);
		} else {
			return "未提交生日";
		}
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password == null ? null : password.trim();
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getQx() {
		return qx;
	}

	public void setQx(String qx) {
		this.qx = qx == null ? null : qx.trim();
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex == null ? null : sex.trim();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status == null ? null : status.trim();
	}

	public Date getBegintime() {
		return begintime;
	}

	public void setBegintime(Date begintime) {
		this.begintime = begintime;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
}