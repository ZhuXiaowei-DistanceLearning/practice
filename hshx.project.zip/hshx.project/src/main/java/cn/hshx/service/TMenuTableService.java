package cn.hshx.service;

import cn.hshx.pojo.TMenuTable;
import pojo.EasyUIDataGridResult;

public interface TMenuTableService {

	EasyUIDataGridResult pageQuery(int page, int rows);

	void pay(TMenuTable model);

}
