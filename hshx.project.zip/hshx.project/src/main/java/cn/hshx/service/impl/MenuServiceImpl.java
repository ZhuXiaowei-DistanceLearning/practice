package cn.hshx.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hshx.mapper.MenuMapper;
import cn.hshx.pojo.Menu;
import cn.hshx.pojo.MenuExample;
import cn.hshx.service.MenuService;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

@Service
@Transactional
public class MenuServiceImpl implements MenuService {
	@Autowired
	private MenuMapper menuMapper;

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		PageHelper.startPage(page, rows);
		MenuExample example = new MenuExample();
		List<Menu> list = menuMapper.selectByExample(example);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<Menu> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public E3Result delete(String ids) {
		String[] id = ids.split(",");
		for (String string : id) {
			menuMapper.deleteByPrimaryKey(string);
		}
		return E3Result.ok(200);
	}

	@Override
	public void edit(Menu college) {
		Menu collegeEdit = menuMapper.selectByPrimaryKey(college.getId());
		collegeEdit.setName(college.getName());
		collegeEdit.setSpecial(college.getSpecial());
		collegeEdit.setCategory(college.getCategory());
		collegeEdit.setMoney(college.getMoney());
		collegeEdit.setMaterial(college.getMaterial());
		menuMapper.updateByPrimaryKey(collegeEdit);
	}

	@Override
	public void save(Menu model) {
		menuMapper.insertSelective(model);
	}

	@Override
	public List<Menu> findAll() {
		MenuExample example = new MenuExample();
		List<Menu> list = menuMapper.selectByExample(example);
		return list;
	}
}
