package cn.hshx.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hshx.mapper.DeskMapper;
import cn.hshx.mapper.TMenuTableMapper;
import cn.hshx.pojo.Desk;
import cn.hshx.pojo.DeskExample;
import cn.hshx.pojo.TMenuTable;
import cn.hshx.pojo.TMenuTableExample;
import cn.hshx.pojo.TMenuTableExample.Criteria;
import cn.hshx.service.TableService;
import pojo.EasyUIDataGridResult;

@Service
@Transactional
public class TableServiceImpl implements TableService {
	@Autowired
	private DeskMapper deskMapper;
	@Autowired
	private TMenuTableMapper tMenuTableMapper;

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		PageHelper.startPage(page, rows);
		DeskExample example = new DeskExample();
		List<Desk> list = deskMapper.selectByExample(example);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<Desk> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public void edit(Desk model) {
		model.setStatus("1");
		deskMapper.updateByPrimaryKey(model);
	}

	@Override
	public void money(String mid, String tid, String money) {
		TMenuTableExample example = new TMenuTableExample();
		Criteria criteria = example.createCriteria();
		criteria.andMenuIdEqualTo(mid);
		criteria.andTableIdEqualTo(tid);
		List<TMenuTable> list = tMenuTableMapper.selectByExample(example);
		if (list.size()==0) {
			TMenuTable table;
			if (list.size() != 0) {
				table = list.get(0);
			} else {
				table = new TMenuTable();
				table.setMoney(0);
			}
			TMenuTable record = new TMenuTable();
			record.setBegintime(new Date());
			record.setMenuId(mid);
			record.setTableId(tid);
			int pay = table.getMoney() + Integer.parseInt(money);
			record.setMoney(pay);
			tMenuTableMapper.insert(record);
		} else {
			TMenuTable record = list.get(0);
			record.setMoney(Integer.parseInt(money) + record.getMoney());
			tMenuTableMapper.updateByPrimaryKey(record);
		}

	}

}
