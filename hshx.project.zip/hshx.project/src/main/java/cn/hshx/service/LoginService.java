package cn.hshx.service;

import cn.hshx.pojo.User;

public interface LoginService {

	User login(String username, String password);

}
