package cn.hshx.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hshx.mapper.UserMapper;
import cn.hshx.pojo.Menu;
import cn.hshx.pojo.User;
import cn.hshx.pojo.UserExample;
import cn.hshx.service.UserService;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	private UserMapper userMapper;

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		PageHelper.startPage(page, rows);
		UserExample example = new UserExample();
		List<User> list = userMapper.selectByExample(example);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<User> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public E3Result delete(String ids) {
		String[] id = ids.split(",");
		for (String string : id) {
			userMapper.deleteByPrimaryKey(string);
		}
		return E3Result.ok(200);
	}

	@Override
	public void edit(User college) {
		User collegeEdit = userMapper.selectByPrimaryKey(college.getId());
		collegeEdit.setName(college.getName());
		collegeEdit.setAge(college.getAge());
		collegeEdit.setPassword(college.getPassword());
		collegeEdit.setQx(college.getQx());
		collegeEdit.setSalary(college.getSalary());
		collegeEdit.setSex(college.getSex());
		collegeEdit.setStatus(college.getStatus());
		userMapper.updateByPrimaryKey(collegeEdit);
	}

	@Override
	public void save(User model) {
		userMapper.insertSelective(model);
	}

}
