package cn.hshx.service;

import java.util.List;

import cn.hshx.pojo.Menu;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

public interface MenuService {

	EasyUIDataGridResult pageQuery(int page, int rows);

	E3Result delete(String ids);

	void edit(Menu model);

	void save(Menu model);

	List<Menu> findAll();

}
