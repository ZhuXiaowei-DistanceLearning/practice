package cn.hshx.service;

import cn.hshx.pojo.Desk;
import cn.hshx.pojo.TMenuTable;
import pojo.EasyUIDataGridResult;

public interface TableService {

	EasyUIDataGridResult pageQuery(int page, int rows);

	void edit(Desk model);

	void money(String mid, String tid, String money);

}
