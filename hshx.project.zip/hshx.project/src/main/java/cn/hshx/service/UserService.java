package cn.hshx.service;

import cn.hshx.pojo.User;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

public interface UserService {

	EasyUIDataGridResult pageQuery(int page, int rows);

	E3Result delete(String ids);

	void save(User model);

	void edit(User model);

}
