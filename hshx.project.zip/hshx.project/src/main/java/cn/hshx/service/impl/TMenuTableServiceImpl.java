package cn.hshx.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hshx.mapper.DeskMapper;
import cn.hshx.mapper.TMenuTableMapper;
import cn.hshx.pojo.Desk;
import cn.hshx.pojo.DeskExample;
import cn.hshx.pojo.TMenuTable;
import cn.hshx.pojo.TMenuTableExample;
import cn.hshx.pojo.TMenuTableExample.Criteria;
import cn.hshx.service.TMenuTableService;
import pojo.EasyUIDataGridResult;

@Service
@Transactional
public class TMenuTableServiceImpl implements TMenuTableService {
	@Autowired
	private TMenuTableMapper tMenuTableMapper;
	@Autowired
	private DeskMapper deskMapper;

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		PageHelper.startPage(page, rows);
		TMenuTableExample example = new TMenuTableExample();
		List<TMenuTable> list = tMenuTableMapper.selectByExample(example);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<TMenuTable> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public void pay(TMenuTable model) {
		TMenuTableExample example = new TMenuTableExample();
		Criteria criteria = example.createCriteria();
		criteria.andTableIdEqualTo(model.getTableId());
		List<TMenuTable> list = tMenuTableMapper.selectByExample(example);
		TMenuTable table = list.get(0);
		table.setEndtime(new Date());
		tMenuTableMapper.updateByPrimaryKey(table);
		DeskExample examples = new DeskExample();
		cn.hshx.pojo.DeskExample.Criteria criteria2 = examples.createCriteria();
		criteria2.andIdEqualTo(model.getTableId());
		List<Desk> desk = deskMapper.selectByExample(examples);
		Desk record = desk.get(0);
		record.setStatus("0");
		record.setPeople(0);
		record.setNote("");
		deskMapper.updateByPrimaryKey(record);
	}
}
