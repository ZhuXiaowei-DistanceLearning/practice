package cn.cart.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cart.service.OrderService;
import cn.csmzxy.pojo.OrderVo;
import cn.csmzxy.pojo.TItem;
import cn.csmzxy.pojo.TOrder;
import cn.csmzxy.pojo.TUser;
import cn.csmzxy.pojo.TUserExample;
import common.pojo.EasyUIDataGridResult;

@Controller
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/orderPay")
	public String order(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "price") Long price, String title, @RequestParam(value = "numForm") Integer num,
			String imgurl, String ids) throws Exception {
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		TItem item = new TItem();
		item.setPrice(price);
		item.setId(Long.parseLong(ids));
		item.setTitle(title);
		item.setImgurl(imgurl);
		item.setNum(num);
		request.setAttribute("user", user);
		request.setAttribute("item", item);
		return "/order-cart";
	}

	@RequestMapping("/create")
	public String create(TOrder order,TUser user,HttpServletRequest request,HttpServletResponse response) throws Exception{
		TUser userInfo = (TUser) request.getAttribute("user");
		if(user==null){
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		user.setId(userInfo.getId());
		orderService.createOrder(order,user);
		request.setAttribute("order", order);
		return "/pay";
	}
	
	@RequestMapping("/findAll")
	@ResponseBody
	public EasyUIDataGridResult findAll(int page,int rows){
		EasyUIDataGridResult list = orderService.findAll(page,rows);
		return list;
	}
	
	@RequestMapping("/findUserOrder")
	public String findUserOrder(HttpServletRequest request,HttpServletResponse response) throws Exception{
		TUser user = (TUser) request.getAttribute("user");
		if(user==null){
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		List<TOrder> order = orderService.findUserOrder(user.getId());
		request.setAttribute("order", order);
		return "/orderlist";
	}
}
