package cn.cart.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.cart.service.CartService;
import cn.csmzxy.pojo.TUser;
import common.utils.CookieUtils;
import common.utils.E3Result;

@Controller
@RequestMapping("/user")
public class UserController {
	@Value("${IMAGE_USER_URL}")
	private String IMAGE_USER_URL;
	@Value("${IMAGE_SERVER_URL}")
	private String IMAGE_SERVER_URL;

	@Autowired
	private CartService cartService;

	@RequestMapping("/info")
	public String getUserInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		request.setAttribute("user", user);
		return "/myAccount";
	}

	@RequestMapping("/edit")
	public String editUserInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		if (user.getImgurl() != null) {
			user.setImgurl(IMAGE_SERVER_URL + user.getImgurl().substring(user.getImgurl().lastIndexOf("/")));
		}
		request.setAttribute("user", user);
		return "/modifyuserinfo";
	}

	@RequestMapping("/img")
	public String modifyUserImg(TUser user, HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "file") MultipartFile file) throws Exception {
		TUser userInfo = (TUser) request.getAttribute("user");
		if (userInfo == null) {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
		}
		if (StringUtils.isNoneBlank(file.getOriginalFilename())) {
			String picName = UUID.randomUUID().toString();
			String originalFilename = file.getOriginalFilename();
			String extName = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
			String imgUrl = IMAGE_USER_URL + picName + "." + extName;
			file.transferTo(new File(imgUrl));
			String WebImgUrl = IMAGE_SERVER_URL + picName + "." + extName;
			user.setImgurl(WebImgUrl);
			request.setAttribute("user", user);
			return "/modifyuserinfo";
		}
		user.setCreated(user.getCreated());
		user.setUpdated(new Date());
		user.setImgurl(IMAGE_USER_URL + user.getImgurl().substring(user.getImgurl().lastIndexOf("/")));
		int i = cartService.editUserInfo(user);
		if (i == 0) {
			return "/modifyuserinfo";
		}
		request.setAttribute("user", user);
		return "/myAccount";
	}

	@RequestMapping("/logout")
	public void logout(HttpServletResponse response, HttpServletRequest request) throws Exception {
		String token = "token";
		CookieUtils.deleteCookie(request, response, token);
		response.sendRedirect("http://120.79.68.113:8082/index.do");
	}
}
