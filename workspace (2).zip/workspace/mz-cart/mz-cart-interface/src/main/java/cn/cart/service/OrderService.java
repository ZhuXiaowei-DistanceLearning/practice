package cn.cart.service;

import java.util.List;

import cn.csmzxy.pojo.TOrder;
import cn.csmzxy.pojo.TUser;
import common.pojo.EasyUIDataGridResult;

public interface OrderService {

	public void createOrder(TOrder order, TUser user);

	public EasyUIDataGridResult findAll(int page, int rows);

	public List<TOrder> findUserOrder(String id);

}
