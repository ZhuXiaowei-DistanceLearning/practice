package cn.cart.service;

import java.util.List;

import cn.csmzxy.pojo.TItem;
import cn.csmzxy.pojo.TUser;
import common.utils.E3Result;

public interface CartService {

	public E3Result addCart(String id, Long itemId, Integer num);

	public List<TItem> getCatList(String id);

	public int editUserInfo(TUser user);

	public E3Result delete(Long itemId, String userId);

	public String selectByUserInfo(String id);

}
