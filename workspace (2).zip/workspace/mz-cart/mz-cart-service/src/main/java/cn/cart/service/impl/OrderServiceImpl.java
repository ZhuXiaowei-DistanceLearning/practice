package cn.cart.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.container.page.PageHandler;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.cart.service.OrderService;
import cn.csmzxy.mapper.TOrderMapper;
import cn.csmzxy.pojo.TOrder;
import cn.csmzxy.pojo.TOrderExample;
import cn.csmzxy.pojo.TOrderExample.Criteria;
import cn.csmzxy.pojo.TUser;
import common.pojo.EasyUIDataGridResult;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {

	@Autowired
	private TOrderMapper orderMapper;

	@Override
	public void createOrder(TOrder order, TUser user) {
		order.setOrderId(UUID.randomUUID().toString());
		order.setUserId(user.getId());
		order.setBuyerNick(user.getUsername());
		order.setStatus(1);
		order.setCreateTime(new Date());
		orderMapper.insert(order);
	}

	@Override
	public EasyUIDataGridResult findAll(int page,int rows) {
		PageHelper.startPage(page, rows);
		TOrderExample example = new TOrderExample();
		List<TOrder> list = orderMapper.selectByExample(example);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		PageInfo<TOrder> info = new PageInfo<>(list);
		result.setRows(list);
		result.setTotal(info.getTotal());
		return result;
	}

	@Override
	public List<TOrder> findUserOrder(String id) {
		TOrderExample example = new TOrderExample();
		Criteria criteria = example.createCriteria();
		criteria.andUserIdEqualTo(id);
		List<TOrder> list = orderMapper.selectByExample(example );
		try{
		return list;
		}catch(Exception e){
			return null;
		}
	}
}
