package school.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import school.dao.StudentDao;
import school.po.Student;
import school.po.User;
import school.service.StudentService;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao studentDao;

	public Student login(Student student) {
		return studentDao.login(student.getSname(), student.getPassword());
	}

}
