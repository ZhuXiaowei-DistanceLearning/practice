package school.service;

import school.po.Student;
import school.po.User;

public interface StudentService {
	public Student login(Student student);
}
