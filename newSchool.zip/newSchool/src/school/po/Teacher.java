package school.po;
// default package



/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher  implements java.io.Serializable {


    // Fields    

     private Integer tid;
     private String tname;
     private String tsex;
     private String tage;
     private String title;
     private String password;


    // Constructors

    /** default constructor */
    public Teacher() {
    }

    
    /** full constructor */
    public Teacher(String tname, String tsex, String tage, String title, String password) {
        this.tname = tname;
        this.tsex = tsex;
        this.tage = tage;
        this.title = title;
        this.password = password;
    }

   
    // Property accessors

    public Integer getTid() {
        return this.tid;
    }
    
    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public String getTname() {
        return this.tname;
    }
    
    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTsex() {
        return this.tsex;
    }
    
    public void setTsex(String tsex) {
        this.tsex = tsex;
    }

    public String getTage() {
        return this.tage;
    }
    
    public void setTage(String tage) {
        this.tage = tage;
    }

    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
   








}