package school.po;
// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private String name;
     private Set exams = new HashSet(0);


    // Constructors

    /** default constructor */
    public Subject() {
    }

    
    /** full constructor */
    public Subject(String name, Set exams) {
        this.name = name;
        this.exams = exams;
    }

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public Set getExams() {
        return this.exams;
    }
    
    public void setExams(Set exams) {
        this.exams = exams;
    }
   








}