package school.po;
// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student  implements java.io.Serializable {


    // Fields    

     private Integer sid;
     private Class classs;
     private String sname;
     private String sex;
     private String scity;
     private Integer yearId;
     private String password;
     private Set scores = new HashSet(0);

    public Integer getSid() {
        return this.sid;
    }
    
    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Class getClasss() {
		return classs;
	}

	public void setClasss(Class classs) {
		this.classs = classs;
	}

	public String getSname() {
        return this.sname;
    }
    
    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSex() {
        return this.sex;
    }
    
    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getScity() {
        return this.scity;
    }
    
    public void setScity(String scity) {
        this.scity = scity;
    }

    public Integer getYearId() {
        return this.yearId;
    }
    
    public void setYearId(Integer yearId) {
        this.yearId = yearId;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public Set getScores() {
        return this.scores;
    }
    
    public void setScores(Set scores) {
        this.scores = scores;
    }
   








}