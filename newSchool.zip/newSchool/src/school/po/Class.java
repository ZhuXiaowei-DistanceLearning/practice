package school.po;
// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Class entity. @author MyEclipse Persistence Tools
 */

public class Class  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private Year year;
     private String classname;
     private String slogan;
     private String flag;
     private Set students = new HashSet(0);


    // Constructors

    /** default constructor */
    public Class() {
    }

    
    /** full constructor */
    public Class(Year year, String classname, String slogan, String flag, Set students) {
        this.year = year;
        this.classname = classname;
        this.slogan = slogan;
        this.flag = flag;
        this.students = students;
    }

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public Year getYear() {
        return this.year;
    }
    
    public void setYear(Year year) {
        this.year = year;
    }

    public String getClassname() {
        return this.classname;
    }
    
    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getSlogan() {
        return this.slogan;
    }
    
    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public String getFlag() {
        return this.flag;
    }
    
    public void setFlag(String flag) {
        this.flag = flag;
    }

    public Set getStudents() {
        return this.students;
    }
    
    public void setStudents(Set students) {
        this.students = students;
    }
   








}