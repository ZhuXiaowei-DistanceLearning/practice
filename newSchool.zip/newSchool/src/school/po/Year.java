package school.po;
// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Year entity. @author MyEclipse Persistence Tools
 */

public class Year  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private String yearname;
     private Set classes = new HashSet(0);


    // Constructors

    /** default constructor */
    public Year() {
    }

    
    /** full constructor */
    public Year(String yearname, Set classes) {
        this.yearname = yearname;
        this.classes = classes;
    }

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getYearname() {
        return this.yearname;
    }
    
    public void setYearname(String yearname) {
        this.yearname = yearname;
    }

    public Set getClasses() {
        return this.classes;
    }
    
    public void setClasses(Set classes) {
        this.classes = classes;
    }
   








}