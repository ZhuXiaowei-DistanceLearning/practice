package school.po;
// default package

import java.util.HashSet;
import java.util.Set;


/**
 * Exam entity. @author MyEclipse Persistence Tools
 */

public class Exam  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private Subject subject;
     private String name;
     private Set scores = new HashSet(0);


    // Constructors

    /** default constructor */
    public Exam() {
    }

    
    /** full constructor */
    public Exam(Subject subject, String name, Set scores) {
        this.subject = subject;
        this.name = name;
        this.scores = scores;
    }

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public Subject getSubject() {
        return this.subject;
    }
    
    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public Set getScores() {
        return this.scores;
    }
    
    public void setScores(Set scores) {
        this.scores = scores;
    }
   








}