package school.dao;

import school.dao.base.BaseDao;
import school.po.Student;
import school.po.User;

public interface StudentDao extends BaseDao<User> {
	public Student login(String username, String password);
}
