package school.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import school.dao.StudentDao;
import school.dao.base.BaseDaoImpl;
import school.po.Student;
import school.po.User;

@Repository
public class StudentDaoImpl extends BaseDaoImpl<User> implements StudentDao {

	@Override
	public Student login(String sname, String password) {
		List<Student> list = this.getHibernateTemplate().find("from Student where sname=? and password = ?", sname,
				password);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

}
