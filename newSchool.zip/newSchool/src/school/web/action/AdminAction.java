package school.web.action;

import school.po.Admin;
import school.web.action.base.BaseAction;

public class AdminAction extends BaseAction<Admin> {

}
