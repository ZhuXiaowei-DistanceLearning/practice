package school.web.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import school.po.Student;
import school.service.StudentService;
import school.web.action.base.BaseAction;

@Controller
@Scope("prototype")
public class StudentAction extends BaseAction<Student> {
	@Resource
	private StudentService studentService;

	public String login() {
		studentService.login(model);
		return "login";
	}
}
