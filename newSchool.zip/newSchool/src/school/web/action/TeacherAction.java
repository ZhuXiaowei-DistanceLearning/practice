package school.web.action;

import school.po.Teacher;
import school.web.action.base.BaseAction;

public class TeacherAction extends BaseAction<Teacher> {

}
