package ������;

import java.util.Scanner;

public class plactise {
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		double weight=sc.nextDouble();
		double height=sc.nextDouble();
		final double a=0.45359237;
		final double b=0.0254;
		double weightInKilograms=weight*a;
		double heightInMeter=height*b;
		double BIM=weightInKilograms/(heightInMeter*heightInMeter);
		System.out.println("Your BIM is:"+BIM);
		if(BIM<16){
			System.out.println("����ƫ��");
		}
		else if(BIM<18){
			System.out.println("ƫ��");
		}
		else if(BIM<24){
			System.out.println("��������");
		}
		else if(BIM<29){
			System.out.println("����");
		}
		else if(BIM<35){
			System.out.println("���س���");
		}
	}
}
