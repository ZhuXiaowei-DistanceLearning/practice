package ������;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeSet;

public class test {
	public static void main(String[] args) {
		String[] num = { "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q",
				"K", "A", "2" };
		String[] color = { "����", "����", "��Ƭ", "÷��" };
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		ArrayList<Integer> poker = new ArrayList<Integer>();
		int index = 0;
		for (String s1 : num) {
			for (String s2 : color) {
				hm.put(index, s2.concat(s1));
				poker.add(index);
				index++;
			}
		}
		hm.put(index, "С��");
		poker.add(index);
		index++;
		hm.put(index, "����");
		poker.add(index);

		// ϴ��
		Collections.shuffle(poker);
		// ����
		TreeSet<Integer> a = new TreeSet<Integer>();
		TreeSet<Integer> b = new TreeSet<Integer>();
		TreeSet<Integer> c = new TreeSet<Integer>();
		TreeSet<Integer> dipai = new TreeSet<Integer>();

		for (int i = 0; i < poker.size(); i++) {
			if (i >= poker.size() - 3) {
				dipai.add(poker.get(i));
			} else if (i % 3 == 0) {
				a.add(poker.get(i));
			} else if (i % 3 == 1) {
				b.add(poker.get(i));
			} else {
				c.add(poker.get(i));
			}
		}
		lookPoker(hm, a, "a");
		lookPoker(hm, b, "b");
		lookPoker(hm, c, "c");
		lookPoker(hm, dipai, "����");
	}
	
	public static void lookPoker(HashMap<Integer,String>hm,TreeSet<Integer> ts,String name){
		for(Integer i : ts){
			System.out.print(hm.get(i)+" ");
		}
		System.out.println();
	}
}
