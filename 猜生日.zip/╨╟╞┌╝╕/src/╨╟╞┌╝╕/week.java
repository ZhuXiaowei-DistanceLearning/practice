package ���ڼ�;

import java.util.Scanner;

public class week {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("��������:");
		System.out.println("��������:");
		System.out.println("��������:");
		double year = sc.nextInt();
		double month = sc.nextInt();
		double day = sc.nextInt();
		double j = year / 100;
		double h = (int) (day + 26 * (month + 1) / 10 + (year % 100) * 100
				+ ((year * 0.01) * 100 / 4) + (j / 4) + (5 * j)) % 7;
		System.out.println("Day of the week is " + h);
	}
}
