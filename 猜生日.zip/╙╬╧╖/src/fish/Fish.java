package fish;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class Fish {

	int x;
	int y;
	int step;
	int width;
	int height;
	Image[] images;
	Image image;
	int index;

	public Fish(String string) throws IOException {
		images = new Image[10];
		for (int i = 0; i < images.length; i++) {
			images[i] = ImageIO.read(new File(string + "_"
					+ String.format("%02d", (i + 1)) + ".png"));
		}
		index = 0;
		image = images[index];
		width = image.getWidth(null);
		height = image.getHeight(null);
		Random r = new Random();
		x = r.nextInt(800 - width);
		y = r.nextInt(500 - height);
		step = r.nextInt(3) + 1;
	}
}
