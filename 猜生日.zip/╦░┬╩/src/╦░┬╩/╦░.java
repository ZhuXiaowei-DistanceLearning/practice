package ˰��;

import java.util.Scanner;

public class ˰ {
	public static void main(String[] args) {
	int surplus = 0;
	int surplus1 = 0;
	int surplus2 = 0;
	int surplus3 = 0;
	int surplus4 = 0;
	int surplus5 = 0;
	int surplus7 = 0;
	int surplus6 = 0;
	int surplus8 = 0;
	int surplus9 = 0;
	int surplus10 = 0;
	int surplus11 = 0;
	int surplus12 = 0;
	Scanner sc = new Scanner(System.in);
	System.out.println("������0-4�����ֵǼ�����:");
	int status = sc.nextInt();
	System.out.println("��������������:");
	int income = sc.nextInt();
	if (status == 0) {
		if (income > 8350) {
			surplus = (int) (8350 * 0.1);
			surplus1 = (income - 8350);
			if (surplus1 > 33950) {
				surplus2 = (int) ((33950 - 8351) * 0.15);
				surplus3 = (surplus1 - (33950 - 8351));
				if (surplus3 > 82250) {
					surplus4 = (int) ((82250 - 33951) * 0.25);
					surplus5 =( surplus3 - (52250 - 33951));
					if (surplus5 > (171550-82250)) {
						surplus8 = (int) ((171550 - 82251) * 0.28);
						surplus9 = (surplus5 - (171550 - 82251));
						if (surplus9 > (372950-171550)) {
							surplus10 = (int) ((372950-171550) * 0.33);
							surplus12=(int) ((income-372950)*0.35);
						}else{
						}
					}else{
					}
					}else{}
				}else{}
			}else{}
		}else{
			
		}
	System.out.println("You shoule pay tax Money is:"+(surplus+surplus2+surplus4+surplus8+surplus10+surplus12));
}
}
