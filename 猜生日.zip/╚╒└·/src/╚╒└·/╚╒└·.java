package ����;

import java.util.Scanner;

public class ���� {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("���������:");
		int a = sc.nextInt();
		System.out.println("�������·�:");
		int b = sc.nextInt();
		PrintMonth(a, b);
	}

	public static void PrintMonth(int year, int month) {
		// TODO �Զ����ɵķ������
		PrintMonthTitle(year, month);
		PrintMonthBody(year, month);
	}

	public static void PrintMonthTitle(int year, int month) {
		System.out.println("           " + getMonthName(month) + " " + year);
		System.out.println("---------------------------------");
		System.out.println(" Sun" + " " + " Mon" + " " + " Tue" + " " + " Wed"
				+ " " + " Thu" + " " + " Fri" + " " + " Sat");
	}

	public static String getMonthName(int month) {
		String MonthName = "";

		if (month == 1)
			MonthName = "Monday";
		else if (month == 2)
			MonthName = "Tuesday";
		else if (month == 3)
			MonthName = "Wednesday";
		else if (month == 4)
			MonthName = "Thursday";
		else if (month == 5)
			MonthName = "Firday";
		else if (month == 6)
			MonthName = "June";
		else if (month == 7)
			MonthName = "July";
		return MonthName;
	}

	public static void PrintMonthBody(int year, int month) {
		int startday = getStartDay(year, month);
		int numberOf = getNumberOfInMonth(year, month);
		int i = 0;
		for (; i < startday; i++)
			System.out.print("    ");
		for (i = 1; i < numberOf; i++) {
			System.out.printf("%4d", i);
			if ((i + startday) % 7 == 0)
				System.out.println();
		}
		System.out.println();
	}

	public static int getStartDay(int year, int month) {
		final int StarDayJan = 3;
		int totalnumberofdays = getTotalNumberOfDay(year, month);
		return (totalnumberofdays + StarDayJan) % 7;
	}

	public static int getTotalNumberOfDay(int year, int month) {
		int total = 0;
		for (int i = 1800; i < year; i++) {
			if (isLeapYear(i))
				total = total + 366;
			else
				total = total + 365;
		}
		for (int i = 1; i < month; i++) {
			total = total + getNumberOfInMonth(year, i);
		}
		return total;
	}

	public static int getNumberOfInMonth(int year, int month) {
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8
				|| month == 10 || month == 12)
			return 31;
		if (month == 4 || month == 6 || month == 9 || month == 11)
			return 30;
		if (month == 2)
			return isLeapYear(year) ? 29 : 28;
		return 0;
	}

	public static boolean isLeapYear(int year) {
		return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
	}
}
