package cn.cart.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.cart.service.CartService;
import cn.csmzxy.mapper.TItemMapper;
import cn.csmzxy.mapper.TUserMapper;
import cn.csmzxy.pojo.TItem;
import cn.csmzxy.pojo.TUser;
import common.utils.E3Result;
import common.utils.JsonUtils;
import jedis.JedisClient;

@Service
@Transactional
public class CartServiceImpl implements CartService {

	@Autowired
	private JedisClient jedisClient;
	@Autowired
	private TItemMapper itemMapper;
	@Autowired
	private TUserMapper userMapper;

	private static final String REDIS_CART_PRE = "CART";

	private String imgUrl = "http://localhost:8080/img/";

	@Override
	public E3Result addCart(String id, Long itemId, Integer num) {
		Boolean hexists = jedisClient.hexists(REDIS_CART_PRE + ":" + id, itemId + "");
		if (hexists) {
			String json = jedisClient.hget(REDIS_CART_PRE + ":" + id, itemId + "");
			TItem item = JsonUtils.jsonToPojo(json, TItem.class);
			item.setNum(item.getNum() + num);
			jedisClient.hset(REDIS_CART_PRE + ":" + id, itemId + "", JsonUtils.objectToJson(item));
			return E3Result.ok();
		}
		TItem item = itemMapper.selectByPrimaryKey(itemId);
		item.setNum(num);
		item.setImgurl(imgUrl + item.getImgurl().substring(item.getImgurl().lastIndexOf("/")));
		jedisClient.hset(REDIS_CART_PRE + ":" + id, itemId + "", JsonUtils.objectToJson(item));
		return E3Result.ok();
	}

	@Override
	public List<TItem> getCatList(String id) {
		List<String> list = jedisClient.hvals(REDIS_CART_PRE + ":" + id);
		List<TItem> itemList = new ArrayList<>();
		for (String string : list) {
			TItem item = JsonUtils.jsonToPojo(string, TItem.class);
			itemList.add(item);
		}
		return itemList;
	}

	@Override
	public E3Result delete(Long itemId, String userId) {
		jedisClient.hdel(REDIS_CART_PRE + ":" + userId, itemId + "");
		return E3Result.ok();
	}

	@Override
	public int editUserInfo(TUser user) {
		int i = userMapper.updateByPrimaryKeySelective(user);
		return i;
	}

}
