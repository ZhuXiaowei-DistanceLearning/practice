package cn.cart.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cart.service.CartService;
import cn.csmzxy.pojo.TItem;
import cn.csmzxy.pojo.TUser;
import common.utils.CookieUtils;
import common.utils.E3Result;
import common.utils.JsonUtils;

@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private CartService cartService;

	@RequestMapping("/{itemId}")
	public String addCart(@PathVariable Long itemId, Integer num, HttpServletRequest request,
			HttpServletResponse response) {
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			try {
				response.sendRedirect("http://localhost:8083/login.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		E3Result result = cartService.addCart(user.getId(), itemId, num);
		return "/cartSuccess";
	}

	@RequestMapping("/list")
	public String getCartItem(HttpServletRequest request, HttpServletResponse response) {
		List<TItem> list = getCookieList(request);
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			try {
				response.sendRedirect("http://localhost:8083/login.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		List<TItem> cartList = cartService.getCatList(user.getId());
		request.setAttribute("cartList", cartList);
		return "/cart";
	}

	public List<TItem> getCookieList(HttpServletRequest request) {
		String json = CookieUtils.getCookieValue(request, "cart", true);
		if (StringUtils.isBlank(json)) {
			return new ArrayList<>();
		}
		List<TItem> list = JsonUtils.jsonToList(json, TItem.class);
		return list;
	}

	@RequestMapping("/delete/{itemId}")
	public String delete(@PathVariable Long itemId, String userId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		TUser user = (TUser) request.getAttribute("user");
		if (user == null) {
			response.sendRedirect("http://localhost:8083/login.jsp");
		}
		cartService.delete(itemId, user.getId());
		return "redirect:/cart/list.do";
	}

	@RequestMapping("/pay")
	public String pay(Long itemprice, HttpServletRequest request) {
		request.setAttribute("totalprice", itemprice);
		return "/pay";
	}

	@RequestMapping("/orderlist")
	public String orderList(HttpServletRequest request, HttpServletResponse response) {
		TUser user = (TUser) request.getAttribute("user");
		List<TItem> list = cartService.getCatList(user.getId());
		request.setAttribute("list", list);
		request.setAttribute("user", user);
		return "/orderlist";
	}
}
