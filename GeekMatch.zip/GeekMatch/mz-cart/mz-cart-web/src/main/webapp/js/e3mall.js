var E3MALL = {
	checkLogin : function() {
		var _ticket = $.cookie("token");
		if (!_ticket) {
			return;
		}
		$.ajax({
			url : "http://localhost:8083/token/" + _ticket + ".do",
			dataType : "jsonp",
			type : "GET",
			success : function(data) {
				if (data.status == 200) {
					var username = data.data.username;
					var html = username + "，欢迎来到民政图书商城！<a href='http://localhost:8084/user/logout.do'>[退出]</a>";
					$("#loginbar").html(html);
					$("#register").html("");
				}
			}
		});
	}
}

$(function() {
	E3MALL.checkLogin();
});