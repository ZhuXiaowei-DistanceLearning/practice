package cn.cart.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import cn.cart.service.CartService;
import cn.csmzxy.pojo.TUser;
import cn.sso.service.TokenService;
import common.utils.CookieUtils;
import common.utils.E3Result;
import net.sf.jsqlparser.parser.Token;

public class LoginInterceptor implements HandlerInterceptor {

	@Autowired
	private TokenService tokenService;
	@Autowired
	private CartService cartService;

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {

	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {

	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws Exception {
		String token = CookieUtils.getCookieValue(request, "token");
		if (StringUtils.isBlank(token)) {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
			return false;
		}
		E3Result result = tokenService.getUserByToken(token);
		if (result.getStatus() == 200) {
			TUser user = (TUser) result.getData();
			String umgUrl =cartService.selectByUserInfo(user.getId());
			user.setImgurl(umgUrl);
			request.setAttribute("user", user);
			return true;
		} else {
			response.sendRedirect("http://120.79.68.113:8083/login.jsp");
			return false;
		}
	}
}
