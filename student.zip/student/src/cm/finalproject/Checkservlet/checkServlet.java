package cm.finalproject.Checkservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.CheckDao;
import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.*;

public class checkServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Staff_Check> listC = new LinkedList<Staff_Check>();
		try {
			 listC = new CheckDao().dispalyCheck();
			 request.setAttribute("list", listC);
			 request.getRequestDispatcher("/record.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
