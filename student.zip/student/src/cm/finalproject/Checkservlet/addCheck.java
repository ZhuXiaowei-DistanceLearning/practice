package cm.finalproject.Checkservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.CheckDao;
import cm.fianlproject.dao.SalaryDao;
import cm.fianlproject.dao.StaffDao;
import cm.fianlproject.dao.UserDao;

public class addCheck extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String staffid = request.getParameter("staffid");
		String time = request.getParameter("time");
		String note = request.getParameter("note");
		CheckDao ud = new CheckDao();
		try {
			ud.addCheck(staffid, time, note);
			request.getRequestDispatcher("/servlet/check").forward(request, response);
		} catch (Exception e) {

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
