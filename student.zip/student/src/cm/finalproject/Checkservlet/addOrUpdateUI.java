package cm.finalproject.Checkservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.CheckDao;
import cm.fianlproject.dao.SalaryDao;
import cm.fianlproject.dao.StaffDao;
import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.Check;
import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.User;

public class addOrUpdateUI extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String staffid = request.getParameter("staffid");
		String time = request.getParameter("time");
		String note = request.getParameter("note");
		CheckDao ud = new CheckDao();
		try {
			if (time != null) {
				Check salary2 = new Check();
				salary2.setNote(note);
				salary2.setStaffid(staffid);
				salary2.setTime(time);
				ud.updateSalary(salary2);
				request.getRequestDispatcher("/servlet/check").forward(request, response);
			} else {
				Check user = ud.editSalary(staffid);
				request.setAttribute("user", user);
				request.getRequestDispatcher("/addOrEditCheck.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
