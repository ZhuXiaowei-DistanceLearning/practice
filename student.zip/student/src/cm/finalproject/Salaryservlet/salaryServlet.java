package cm.finalproject.Salaryservlet;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.SalaryDao;
import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.Staff_Salary;

public class salaryServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Staff_Salary> list = new LinkedList<Staff_Salary>();
		try {
			list = new SalaryDao().dispalySalary();
			request.setAttribute("list", list);
			request.getRequestDispatcher("/money.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
