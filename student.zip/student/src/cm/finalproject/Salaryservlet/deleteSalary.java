package cm.finalproject.Salaryservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.SalaryDao;
import cm.fianlproject.dao.StaffDao;
import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.User;

public class deleteSalary extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("staffid");
		SalaryDao ud = new SalaryDao();
		try {
			ud.deleteUser(id);
			request.getRequestDispatcher("/servlet/findAllSalary").forward(request, response);
		} catch (Exception e) {

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
