package cm.finalproject.Userservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.User;

public class addOrUpdateUI extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String qx = request.getParameter("qx");
		UserDao ud = new UserDao();
		try {
			if (username != null) {
				User user = new User();
				user.setId(id);
				user.setPassword(password);
				user.setUsername(username);
				user.setQx(qx);
				ud.updateUser(user);
				request.getRequestDispatcher("/servlet/findAll").forward(request, response);
			} else {
				User user = ud.editUser(id);
				request.setAttribute("user", user);
				request.getRequestDispatcher("/addOrEditCourse.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
