package cm.finalproject.Staffservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.StaffDao;
import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.User;

public class addOrUpdateUI extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String sex = request.getParameter("sex");
		String education = request.getParameter("education");
		String jiguan = request.getParameter("jiguan");
		StaffDao ud = new StaffDao();
		try {
			if (name != null) {
				Staff staff = new Staff();
				staff.setAge(age);
				staff.setEducation(education);
				staff.setId(id);
				staff.setJiguan(jiguan);
				staff.setName(name);
				staff.setSex(sex);
				ud.updateStaff(staff);
				request.getRequestDispatcher("/servlet/staff").forward(request, response);
			} else {
				Staff user = ud.editStaff(id);
				request.setAttribute("user", user);
				request.getRequestDispatcher("/addOrEditStaff.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
