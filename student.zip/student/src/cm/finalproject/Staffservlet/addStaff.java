package cm.finalproject.Staffservlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.dao.StaffDao;
import cm.fianlproject.dao.UserDao;

public class addStaff extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String username = request.getParameter("name");
		String password = request.getParameter("age");
		String qx = request.getParameter("sex");
		String education = request.getParameter("education");
		String jiguan = request.getParameter("jiguan");
		StaffDao ud = new StaffDao();
		try {
			ud.addStaff(id, username, password, qx, education, jiguan);
			request.getRequestDispatcher("/servlet/staff").forward(request, response);
		} catch (Exception e) {

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doPost(req, resp);
	}

}
