package cm.fianlproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.Staff_Salary;
import cm.fianlproject.entity.User;

public class SalaryDao {
	public List<Staff_Salary> dispalySalary() throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		Statement state2 = con.createStatement();
		String sql = "select * from salary";
		ResultSet rs = state.executeQuery(sql);
		List<Staff_Salary> list = new LinkedList<Staff_Salary>();
		while (rs.next()) {
			String staffid = rs.getString("staffid");
			String time = rs.getString("time");
			String salary = rs.getString("salary");
			Salary salary2 = new Salary();
			salary2.setStaffid(staffid);
			salary2.setTime(time);
			salary2.setSalary(salary);
			String sql2 = "select * from staff where id=" + staffid;
			ResultSet rs2 = state2.executeQuery(sql2);
			Staff staff = new Staff();
			while(rs2.next()){
				String name = rs2.getString("name");
				staff.setName(name);
			}
			Staff_Salary staff_Salary = new Staff_Salary();
			staff_Salary.setSalary(salary2);
			staff_Salary.setStaff(staff);
			list.add(staff_Salary);
		}
		state.close();
		state2.close();
		con.close();
		return list;
	}

	public void deleteUser(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "delete from salary where staffid=" + id;
		state.execute(sql);
		state.close();
		con.close();
	}

	public void addSalary(String staffid, String time, String salary) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "INSERT INTO salary VALUES(?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, staffid);
		ps.setString(2, time);
		ps.setString(3, salary);
		int execute = ps.executeUpdate();
		System.out.println(execute);
		state.close();
		con.close();
	}

	public Salary editSalary(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from salary where staffid=" + id;
		ResultSet rs = state.executeQuery(sql);
		List<Salary> list = new LinkedList<Salary>();
		while (rs.next()) {
			String staffid = rs.getString("staffid");
			String time = rs.getString("time");
			String salary = rs.getString("salary");
			Salary salary2 = new Salary();
			salary2.setStaffid(staffid);
			salary2.setTime(time);
			salary2.setSalary(salary);
			list.add(salary2);
		}
		Salary user = list.get(0);
		state.close();
		con.close();
		return user;
	}

	public void updateSalary(Salary salary) throws Exception {
		Connection con = DBUtils.getConnection();
		String sql = "update salary set time=?,salary=? where staffid=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, salary.getTime());
		ps.setString(2, salary.getSalary());
		ps.setString(3, salary.getStaffid());
		int count = ps.executeUpdate();
		System.out.println(count);
		ps.close();
		con.close();
	}
}
