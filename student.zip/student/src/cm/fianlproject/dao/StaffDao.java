package cm.fianlproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.User;

public class StaffDao {
	public List<Staff> dispalyStaff() throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from staff";
		ResultSet rs = state.executeQuery(sql);
		List<Staff> list = new LinkedList<Staff>();
		while (rs.next()) {
			String id = rs.getString("id");
			String name = rs.getString("name");
			String age = rs.getString("age");
			String sex = rs.getString("sex");
			String education = rs.getString("education");
			String jiguan = rs.getString("jiguan");
			Staff staff = new Staff();
			staff.setEducation(education);
			staff.setId(id);
			staff.setJiguan(jiguan);
			staff.setName(name);
			staff.setSex(sex);
			staff.setAge(age);
			list.add(staff);
		}
		return list;
	}

	public void deleteUser(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "delete from staff where id=" + id;
		state.execute(sql);
		state.close();
		con.close();
	}

	public void addStaff(String id, String name, String age, String sex, String education, String jiguan)
			throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "INSERT INTO staff VALUES(?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, name);
		ps.setString(3, age);
		ps.setString(4, sex);
		ps.setString(5, education);
		ps.setString(6, jiguan);
		int execute = ps.executeUpdate();
		System.out.println(execute);
		state.close();
		con.close();
	}

	public void updateStaff(Staff staff) throws Exception {
		Connection con = DBUtils.getConnection();
		String sql = "update staff set name=?,age=?,sex=?,education=?,jiguan=? where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, staff.getName());
		ps.setString(2, staff.getAge());
		ps.setString(3, staff.getSex());
		ps.setString(4, staff.getEducation());
		ps.setString(5, staff.getJiguan());
		ps.setString(6, staff.getId());
		int count = ps.executeUpdate();
		System.out.println(count);
		ps.close();
		con.close();
	}

	public Staff editStaff(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from staff where id=" + id;
		ResultSet rs = state.executeQuery(sql);
		List<Staff> list = new LinkedList<Staff>();
		while (rs.next()) {
			String id2 = rs.getString("id");
			String name = rs.getString("name");
			String age = rs.getString("age");
			String sex = rs.getString("sex");
			String education = rs.getString("education");
			String jiguan = rs.getString("jiguan");
			Staff staff = new Staff();
			staff.setAge(age);
			staff.setEducation(education);
			staff.setId(id2);
			staff.setJiguan(jiguan);
			staff.setName(name);
			staff.setSex(sex);
			list.add(staff);
		}
		Staff user = list.get(0);
		state.close();
		con.close();
		return user;
	}
}
