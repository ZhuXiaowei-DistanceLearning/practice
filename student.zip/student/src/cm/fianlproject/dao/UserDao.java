package cm.fianlproject.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import cm.fianlproject.entity.*;

public class UserDao {
	public User login(User user) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from user";
		ResultSet rs = state.executeQuery(sql);

		while (rs.next()) {
			String name = rs.getString("username");
			String pwd = rs.getString("password");
			if (name.equals(user.getUsername()) && pwd.equals(user.getPassword())) {
				return user;
			}
		}

		rs.close();
		state.close();
		con.close();
		return null;
	}

	public int updateUser(User user) throws Exception {
		Connection con = DBUtils.getConnection();
		String sql = "update user set username=?,password=?,qx=? where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUsername());
		ps.setString(2, user.getPassword());
		ps.setString(3, user.getQx());
		ps.setString(4, user.getId());
		int count = ps.executeUpdate();
		System.out.println(count);
		ps.close();
		con.close();
		return count;
	}

	public List<User> findAll() throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from user";
		ResultSet rs = state.executeQuery(sql);

		List<User> list = new LinkedList<User>();

		while (rs.next()) {
			String id = rs.getString("id");
			String username = rs.getString("username");
			String password = rs.getString("password");
			String qx = rs.getString("qx");
			User user = new User();
			user.setId(id);
			user.setQx(qx);
			user.setPassword(password);
			user.setUsername(username);
			list.add(user);
		}
		state.close();
		con.close();
		return list;
	}

	public User editUser(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from user where id=" + id;
		ResultSet rs = state.executeQuery(sql);
		List<User> list = new LinkedList<User>();
		while (rs.next()) {
			String id2 = rs.getString("id");
			String username = rs.getString("username");
			String password = rs.getString("password");
			String qx = rs.getString("qx");

			User user = new User();
			user.setId(id2);
			user.setQx(qx);
			user.setPassword(password);
			user.setUsername(username);
			list.add(user);
		}
		User user = list.get(0);
		state.close();
		con.close();
		return user;
	}

	public void deleteUser(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "delete from user where id=" + id;
		state.execute(sql);
		state.close();
		con.close();
	}

	public void addUser(String id, String username, String password, String qx) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "INSERT INTO USER VALUES(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, username);
		ps.setString(3, password);
		ps.setString(4, qx);
		int execute = ps.executeUpdate();
		System.out.println(execute);
		state.close();
		con.close();
	}
}
