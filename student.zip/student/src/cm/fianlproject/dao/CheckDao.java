package cm.fianlproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import cm.fianlproject.entity.Check;
import cm.fianlproject.entity.Salary;
import cm.fianlproject.entity.Staff;
import cm.fianlproject.entity.Staff_Check;
import cm.fianlproject.entity.Staff_Salary;

public class CheckDao {
	public List<Staff_Check> dispalyCheck() throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		Statement state2 = con.createStatement();
		String sql = "select * from checkstaff";
		ResultSet rs = state.executeQuery(sql);
		List<Staff_Check> list = new LinkedList<Staff_Check>();
		while (rs.next()) {
			String staffid = rs.getString("staffid");
			String time = rs.getString("time");
			String note = rs.getString("note");
			Check salary2 = new Check();
			salary2.setStaffid(staffid);
			salary2.setTime(time);
			salary2.setNote(note);
			String sql2 = "select * from staff where id=" + staffid;
			ResultSet rs2 = state2.executeQuery(sql2);
			Staff staff = new Staff();
			while (rs2.next()) {
				String name = rs2.getString("name");
				staff.setName(name);
			}
			Staff_Check staff_Salary = new Staff_Check();
			staff_Salary.setChek(salary2);
			staff_Salary.setStaff(staff);
			list.add(staff_Salary);
		}
		state.close();
		state2.close();
		con.close();
		return list;
	}

	public void addCheck(String staffid, String time, String note) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "INSERT INTO checkstaff VALUES(?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, staffid);
		ps.setString(2, time);
		ps.setString(3, note);
		int execute = ps.executeUpdate();
		System.out.println(execute);
		state.close();
		con.close();

	}

	public void updateSalary(Check salary2) throws Exception {
		Connection con = DBUtils.getConnection();
		String sql = "update checkstaff set time=?,note=? where staffid=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, salary2.getTime());
		ps.setString(2, salary2.getNote());
		ps.setString(3, salary2.getStaffid());
		int count = ps.executeUpdate();
		System.out.println(count);
		ps.close();
		con.close();
	}

	public Check editSalary(String staffid) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "select * from checkstaff where staffid=" + staffid;
		ResultSet rs = state.executeQuery(sql);
		List<Check> list = new LinkedList<Check>();
		while (rs.next()) {
			String staffid2 = rs.getString("staffid");
			String time = rs.getString("time");
			String note = rs.getString("note");
			Check salary2 = new Check();
			salary2.setStaffid(staffid2);
			salary2.setTime(time);
			salary2.setNote(note);
			list.add(salary2);
		}
		Check user = list.get(0);
		state.close();
		con.close();
		return user;
	}

	public void deleteUser(String id) throws Exception {
		Connection con = DBUtils.getConnection();
		Statement state = con.createStatement();
		String sql = "delete from checkstaff where staffid=" + id;
		state.execute(sql);
		state.close();
		con.close();
	}
}
