package cm.fianlproject.service;

import cm.fianlproject.dao.UserDao;
import cm.fianlproject.entity.User;


public class UserService {

	private UserDao dao = new UserDao();
	
	// ��½
	public User login(User user) throws Exception {
		
		return dao.login(user);	
	}
	
	// ע��


}
