package cm.fianlproject.entity;

public class Staff_Check {
	private Staff staff;
	private Check check;

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Check getCheck() {
		return check;
	}

	public void setChek(Check check) {
		this.check = check;
	}

}
