package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cm.fianlproject.entity.User;
import cm.fianlproject.service.UserService;

public class loginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");

		User user = new User();
		user.setUsername(name);
		user.setPassword(pwd);
		UserService us = new UserService();
		User userInfo = null;
		try {
			userInfo = us.login(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (userInfo == null) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		} else {
			request.getSession().setAttribute("userInfo", userInfo);
			response.sendRedirect("/student/pages/frame.jsp");
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
