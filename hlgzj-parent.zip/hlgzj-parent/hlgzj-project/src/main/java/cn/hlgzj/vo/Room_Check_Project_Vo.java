package cn.hlgzj.vo;

import java.util.List;

import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheck;

public class Room_Check_Project_Vo {
	private Room room;
	private List<Check> CheckVo;

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public List<Check> getCheckVo() {
		return CheckVo;
	}

	public void setCheckVo(List<Check> checkVo) {
		CheckVo = checkVo;
	}

}
