package cn.hlgzj.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hlgzj.mapper.RoomMapper;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.service.DetailService;
import cn.hlgzj.vo.Detail_Vo;
import cn.hlgzj.vo.Question;
import pojo.EasyUIDataGridResult;

@Controller
@RequestMapping("/detail")
public class DetailController {

	@Autowired
	private DetailService detailService;

	@RequestMapping("/PageQuery")
	@ResponseBody
	public List<Detail_Vo> PageQuery(HttpSession session, HttpServletRequest request) {
		String roomid = (String) session.getAttribute("roomid");
		String bc = (String) session.getAttribute("bc");
		List<Question> question = detailService.findErrorQuestion(roomid, bc);
		List<Detail_Vo> list = detailService.findAll(roomid, bc);
		list.get(0).setErrorQuestion(question.size());
		return list;
	}

	@RequestMapping("/Page")
	public String page(String roomid, String bc, HttpSession session, HttpServletRequest request) {
		List<Question> question = detailService.findErrorQuestion(roomid, bc);
		request.setAttribute("question", question);
		session.setAttribute("roomid", roomid);
		session.setAttribute("bc", bc);
		if (bc.equals("0")) {
			return "/nightdetail";
		} else if (bc.equals("1")) {
			return "/moodNightdetail";
		}
		return null;
	}
}
