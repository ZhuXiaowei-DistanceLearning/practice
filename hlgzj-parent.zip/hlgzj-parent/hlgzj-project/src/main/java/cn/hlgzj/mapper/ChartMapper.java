package cn.hlgzj.mapper;

import cn.hlgzj.vo.ChartTotal;

public interface ChartMapper {

	ChartTotal findAllCheckRoom(String today, String valueOf, String string);
}