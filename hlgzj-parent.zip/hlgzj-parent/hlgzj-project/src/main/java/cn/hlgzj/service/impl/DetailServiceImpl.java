package cn.hlgzj.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hlgzj.mapper.CheckMapper;
import cn.hlgzj.mapper.DetailMapper;
import cn.hlgzj.mapper.RoomCheckMapper;
import cn.hlgzj.mapper.RoomMapper;
import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.Circumstance;
import cn.hlgzj.pojo.Project;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.pojo.RoomExample;
import cn.hlgzj.pojo.RoomTime;
import cn.hlgzj.service.DetailService;
import cn.hlgzj.vo.Detail_Vo;
import cn.hlgzj.vo.Question;
import pojo.EasyUIDataGridResult;

@Service
@Transactional
public class DetailServiceImpl implements DetailService {

	@Autowired
	private DetailMapper detailMapper;

	@Override
	public List<Question> findErrorQuestion(String roomid, String bc) {
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		List<Question> list = detailMapper.findCheckErrorkRoom(roomid, today, bc);
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getCheckRoom().getYes().equals("0")
					&& (list.get(i).getCheckRoom().getCheckId().equals("21"))) {
				list.remove(i);
			}
		}
		return list;
	}

	/**
	 * 查询检查结果
	 */
	@Override
	public List<Detail_Vo> findAll(String roomid, String bc) {
		List<Detail_Vo> list = new ArrayList<>();
		Detail_Vo detail_Vo = null;
		Room room = detailMapper.findRoom(roomid);
		List<Project> listProject = detailMapper.findProject();
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		for (int i = 1; i <= listProject.size(); i++) {
			detail_Vo = new Detail_Vo();
			Project project = detailMapper.findProjectId(String.valueOf(i));
			List<Check> check = detailMapper.findCheck(project.getId());
			Circumstance circumstance = detailMapper.findCircumstance(roomid, today, bc);
			List<CheckRoom> checkRoom = detailMapper.findCheckRoom(project.getId(), bc, today, room.getId());
			/**
			 * 返回检查结果内容
			 */
			detail_Vo.setCheckRoom(checkRoom);
			detail_Vo.setCheck(check);
			detail_Vo.setCircumstance(circumstance);
			detail_Vo.setProject(project);
			detail_Vo.setRoom(room);
			list.add(detail_Vo);
		}
		return list;
	}

}
