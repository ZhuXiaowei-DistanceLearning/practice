package cn.hlgzj.vo;

import cn.hlgzj.pojo.Circumstance;

public class ExportXls {
	private Circumstance circumstance;
	private String name;

	public Circumstance getCircumstance() {
		return circumstance;
	}

	public void setCircumstance(Circumstance circumstance) {
		this.circumstance = circumstance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
