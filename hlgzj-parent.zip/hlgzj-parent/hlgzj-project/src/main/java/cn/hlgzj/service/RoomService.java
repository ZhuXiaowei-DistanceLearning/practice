package cn.hlgzj.service;

import java.util.List;

import cn.hlgzj.vo.ExportXls;
import pojo.EasyUIDataGridResult;

public interface RoomService {

	EasyUIDataGridResult pageQuery(int page, int rows);

	EasyUIDataGridResult findRoom(int page, int rows, String time);

	List<ExportXls> findXlsAll(String times);

}
