package cn.hlgzj.mapper;

import cn.hlgzj.pojo.Circumstance;
import cn.hlgzj.pojo.CircumstanceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CircumstanceMapper {
    int countByExample(CircumstanceExample example);

    int deleteByExample(CircumstanceExample example);

    int insert(Circumstance record);

    int insertSelective(Circumstance record);

    List<Circumstance> selectByExample(CircumstanceExample example);

    int updateByExampleSelective(@Param("record") Circumstance record, @Param("example") CircumstanceExample example);

    int updateByExample(@Param("record") Circumstance record, @Param("example") CircumstanceExample example);
}