package cn.hlgzj.mapper;

import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.CheckRoomExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CheckRoomMapper {
    int countByExample(CheckRoomExample example);

    int deleteByExample(CheckRoomExample example);

    int insert(CheckRoom record);

    int insertSelective(CheckRoom record);

    List<CheckRoom> selectByExample(CheckRoomExample example);

    int updateByExampleSelective(@Param("record") CheckRoom record, @Param("example") CheckRoomExample example);

    int updateByExample(@Param("record") CheckRoom record, @Param("example") CheckRoomExample example);
}