package cn.hlgzj.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.hlgzj.mapper.ExportXlsMapper;
import cn.hlgzj.mapper.RoomCheckMapper;
import cn.hlgzj.mapper.RoomMapper;
import cn.hlgzj.mapper.RoomTimeMapper;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.pojo.RoomExample;
import cn.hlgzj.pojo.RoomTime;
import cn.hlgzj.pojo.RoomTimeExample;
import cn.hlgzj.service.RoomService;
import cn.hlgzj.vo.ExportXls;
import pojo.EasyUIDataGridResult;

@Service
@Transactional
public class RoomServiceImpl implements RoomService {

	@Autowired
	private RoomMapper roomMapper;
	@Autowired
	private RoomTimeMapper roomTimeMapper;
	@Autowired
	private ExportXlsMapper exportXlsMapper;

	@Override
	public EasyUIDataGridResult pageQuery(int page, int rows) {
		/*
		 * RoomCheck roomCheck = new RoomCheck(); Integer id = new Integer(1);
		 * for (int i = 1; i <= 89; i++) { for (int j = 1; j <= 21; j++) {
		 * roomCheck.setId(String.valueOf(id));
		 * roomCheck.setRoomId(String.valueOf(i));
		 * roomCheck.setCheckId(String.valueOf(j));
		 * roomCheckMapper.insert(roomCheck); id++; System.out.println(id); } }
		 */
		RoomExample example = new RoomExample();
		List<Room> list = roomMapper.selectByExample(example);
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		RoomTimeExample roomTimeExample = new RoomTimeExample();
		roomTimeExample.createCriteria().andTodayEqualTo(today);
		List<RoomTime> roomTimeList = roomTimeMapper.selectByExample(roomTimeExample);
		RoomTime roomTime;
		if (roomTimeList.size() == 0 && roomTimeList.isEmpty()) {
			for (Room room : list) {
				roomTime = new RoomTime();
				roomTime.setId(today + "-" + room.getId());
				roomTime.setRoomid(room.getId());
				roomTime.setToday(today);
				roomTimeMapper.insert(roomTime);
			}
		}
		/**
		 * 生成今日数据
		 */
		PageHelper.startPage(page, rows);
		List<RoomTime> list2 = roomTimeMapper.findAll(today);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list2);
		PageInfo<RoomTime> pageInfo = new PageInfo<>(list2);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public EasyUIDataGridResult findRoom(int page, int rows, String time) {
		PageHelper.startPage(page, rows);
		List<RoomTime> list = roomTimeMapper.findAll(time);
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		PageInfo<RoomTime> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		result.setTotal(total);
		return result;
	}

	@Override
	public List<ExportXls> findXlsAll(String times) {
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		List<Room> room = exportXlsMapper.findRoom();
		List<ExportXls> exportXls = new ArrayList<>();
		ExportXls xls = null;
		for (int i = 0; i < room.size(); i++) {
			xls = exportXlsMapper.findAllExportXls(room.get(i).getId(), today, times);
			if (xls == null) {
				xls = new ExportXls();
			}
			xls.setName(room.get(i).getName());
			exportXls.add(xls);
		}
		return exportXls;
	}

}
