package cn.hlgzj.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.hlgzj.service.RoomService;
import cn.hlgzj.vo.ExportXls;
import pojo.EasyUIDataGridResult;
import utils.FileUtils;
import utils.JsonUtils;

@Controller
@RequestMapping("/room")
public class RoomController {
	@Autowired
	private RoomService roomService;
	@Value("${IMAGE_USER_URL}")
	private String IMAGE_USER_URL;
	@Value("${IMAGE_SERVER_URL}")
	private String IMAGE_SERVER_URL;

	/**
	 * 分页查询
	 */
	@RequestMapping("/pageQuery")
	@ResponseBody
	public EasyUIDataGridResult pageQuery(int rows, int page) {
		EasyUIDataGridResult result = roomService.pageQuery(page, rows);
		return result;
	}

	/**
	 * 查找指定日期检查状况页面
	 */
	@RequestMapping("/findRoomPage")
	public String findRoomPage(String time, HttpSession session) {
		session.setAttribute("time", time);
		return "/findRoom";
	}

	/**
	 * 查找指定日期检查状况
	 */
	@RequestMapping("/findRoom")
	@ResponseBody
	public EasyUIDataGridResult findRoom(int rows, int page, HttpSession session) {
		String time = (String) session.getAttribute("time");
		EasyUIDataGridResult result = roomService.findRoom(page, rows, time);
		return result;
	}

	/**
	 * 图片上传
	 */
	@RequestMapping("/img")
	@ResponseBody
	public String addImg(HttpServletRequest request, HttpServletResponse response, MultipartFile file)
			throws Exception {
		if (StringUtils.isNoneBlank(file.getOriginalFilename())) {
			String picName = UUID.randomUUID().toString();
			String originalFilename = file.getOriginalFilename();
			String extName = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
			String LocalimgUrl = IMAGE_USER_URL + picName + "." + extName;
			String imgUrl = IMAGE_SERVER_URL + picName + "." + extName;
			file.transferTo(new File(LocalimgUrl));
			return imgUrl;
		}
		return null;
	}

	/**
	 * 导出表格
	 */
	@RequestMapping("/exportXls")
	public String exportXls(HttpServletRequest request, HttpServletResponse response) throws IOException {
		List<ExportXls> nightlist = roomService.findXlsAll("0");
		List<ExportXls> moodNightlist = roomService.findXlsAll("1");
		// 在内存中创建一个Excel文件，通过输出流写到客户端提供下载
		XSSFWorkbook workbook = new XSSFWorkbook();
		// 创建一个sheet页
		XSSFSheet sheet = workbook.createSheet("晚夜班护理质量检查结果");
		// 设置单元格样式
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);// 右边框
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 下边框
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 左边框
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);// 上边框
		cellStyle.setWrapText(true);
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER); // 居中
		cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		// 设置单元格行宽
		sheet.setColumnWidth(2, 10000);
		sheet.setColumnWidth(4, 10000);
		// 合并单元格
		sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, 0));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 2));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 3, 4));
		// 第一行表头
		XSSFRow headRow = sheet.createRow(0);
		headRow.createCell(0).setCellValue("科室");
		headRow.createCell(1).setCellValue("晚班");
		headRow.createCell(3).setCellValue("夜班");
		// 第二行表头
		XSSFRow secondRow = sheet.createRow(1);
		secondRow.createCell(1).setCellValue("分数");
		secondRow.createCell(2).setCellValue("检查结果");
		secondRow.createCell(3).setCellValue("分数");
		secondRow.createCell(4).setCellValue("检查结果");
		for (int i = 0; i < nightlist.size(); i++) {
			String nightGrade = "";
			String moodNightGrade = "";
			String nightResult = "";
			String moodNightResult = "";
			if (nightlist.get(i).getCircumstance() != null) {
				nightGrade = String.valueOf(nightlist.get(i).getCircumstance().getGrade());
				nightResult = nightlist.get(i).getCircumstance().getResult();
			}
			if (moodNightlist.get(i).getCircumstance() != null) {
				moodNightGrade = String.valueOf(moodNightlist.get(i).getCircumstance().getGrade());
				moodNightResult = moodNightlist.get(i).getCircumstance().getResult();
			}
			XSSFRow dataRow = sheet.createRow(sheet.getLastRowNum() + 1);
			// 设置样式
			dataRow.createCell(0).setCellValue(nightlist.get(i).getName());
			dataRow.createCell(1).setCellValue(nightGrade);
			dataRow.createCell(2).setCellValue(nightResult);
			dataRow.createCell(3).setCellValue(moodNightGrade);
			dataRow.createCell(4).setCellValue(moodNightResult);
		}
		String filename = "晚夜班护理质量检查结果.xlsx";
		String agent = request.getHeader("User-Agent");
		filename = FileUtils.encodeDownloadFilename(filename, agent);
		// 一个流两个头
		ServletOutputStream out = response.getOutputStream();
		String contentType = request.getSession().getServletContext().getMimeType(filename);
		response.setContentType(contentType);
		response.setHeader("content-disposition", "attchment;filename=" + filename);
		workbook.write(out);
		return "";
	}
}
