package cn.hlgzj.vo;

import java.util.List;

import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheck;

public class CheckRoom_Room_Vo {
	private List<CheckRoom> checkRoom;
	private Room room;

	public List<CheckRoom> getCheckRoom() {
		return checkRoom;
	}

	public void setCheckRoom(List<CheckRoom> checkRoom) {
		this.checkRoom = checkRoom;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

}
