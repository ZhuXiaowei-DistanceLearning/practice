package cn.hlgzj.mapper;

import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.Circumstance;
import cn.hlgzj.pojo.Project;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.vo.Detail_Vo;
import cn.hlgzj.vo.Question;

import java.util.List;

public interface DetailMapper {
	List<Detail_Vo> findAll(String roomid);

	Room findRoom(String roomid);

	List<Check> findCheck(String string);

	List<CheckRoom> findCheckRoom(String id, String roomid, String bc, String today);

	Circumstance findCircumstance(String roomid, String today, String bc);

	List<Project> findProject();

	Project findProjectId(String valueOf);

	List<Question> findCheckErrorkRoom(String string, String roomid, String bc);
}