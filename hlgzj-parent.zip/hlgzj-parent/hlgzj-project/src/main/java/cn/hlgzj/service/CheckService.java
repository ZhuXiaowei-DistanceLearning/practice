package cn.hlgzj.service;

import java.util.List;

import cn.hlgzj.pojo.Check;
import cn.hlgzj.vo.Room_Check_Project_Vo;

public interface CheckService {

	Room_Check_Project_Vo PageQuery(String id);

}
