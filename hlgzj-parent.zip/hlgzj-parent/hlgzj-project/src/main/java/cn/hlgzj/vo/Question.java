package cn.hlgzj.vo;

import cn.hlgzj.pojo.CheckRoom;

public class Question {
	private CheckRoom checkRoom;
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public CheckRoom getCheckRoom() {
		return checkRoom;
	}

	public void setCheckRoom(CheckRoom checkRoom) {
		this.checkRoom = checkRoom;
	}

}
