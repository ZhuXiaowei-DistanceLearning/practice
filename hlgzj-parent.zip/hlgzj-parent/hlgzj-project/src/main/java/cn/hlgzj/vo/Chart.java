package cn.hlgzj.vo;

public class Chart {
	private String name;
	private Double nightRate;
	private Double moodNightRate;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getNightRate() {
		return nightRate;
	}

	public void setNightRate(Double nightRate) {
		this.nightRate = nightRate;
	}

	public Double getMoodNightRate() {
		return moodNightRate;
	}

	public void setMoodNightRate(Double moodNightRate) {
		this.moodNightRate = moodNightRate;
	}

}
