package cn.hlgzj.mapper;

import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.pojo.RoomCheckExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RoomCheckMapper {
    int countByExample(RoomCheckExample example);

    int deleteByExample(RoomCheckExample example);

    int deleteByPrimaryKey(String id);

    int insert(RoomCheck record);

    int insertSelective(RoomCheck record);

    List<RoomCheck> selectByExample(RoomCheckExample example);

    RoomCheck selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") RoomCheck record, @Param("example") RoomCheckExample example);

    int updateByExample(@Param("record") RoomCheck record, @Param("example") RoomCheckExample example);

    int updateByPrimaryKeySelective(RoomCheck record);

    int updateByPrimaryKey(RoomCheck record);
}