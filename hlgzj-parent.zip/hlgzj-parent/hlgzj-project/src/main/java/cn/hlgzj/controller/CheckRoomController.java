package cn.hlgzj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.service.CheckRoomService;
import cn.hlgzj.vo.CheckRoom_Room_Vo;
import cn.hlgzj.vo.Room_Check_Project_Vo;
import utils.E3Result;

@Controller
@RequestMapping("/checkroom")
public class CheckRoomController {

	@Autowired
	private CheckRoomService roomCheckService;

	@RequestMapping("/record")
	@ResponseBody
	public E3Result Record(CheckRoom_Room_Vo vo, String bc) {
		E3Result result = roomCheckService.insertRecord(vo, bc);
		return result;
	}
}
