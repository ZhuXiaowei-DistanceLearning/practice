package cn.hlgzj.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.hlgzj.mapper.ChartMapper;
import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.service.ChartService;
import cn.hlgzj.vo.Chart;
import cn.hlgzj.vo.ChartTotal;
import cn.hlgzj.vo.Question;
import net.sf.jsqlparser.expression.StringValue;

@Service
@Transactional
public class ChartServiceImpl implements ChartService {
	@Autowired
	private ChartMapper chartMapper;

	@Override
	public List<Chart> findChart() {
		/**
		 * 获取今日各项统计数据
		 */
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		List<ChartTotal> nightChartTotal = new ArrayList<>();
		List<ChartTotal> moodnightChartTotal = new ArrayList<>();
		ChartTotal cTotal = null;
		ChartTotal cTotal2 = null;
		for (int i = 1; i < 21; i++) {
			String cid = String.valueOf(i);
			cTotal = chartMapper.findAllCheckRoom(today, cid, "0");
			cTotal2 = chartMapper.findAllCheckRoom(today, cid, "1");
			nightChartTotal.add(cTotal);
			moodnightChartTotal.add(cTotal2);
		}
		/**
		 * 计算百分率
		 */
		List<Chart> cList = new ArrayList<>();
		Chart chart2 = null;
		for (int i = 0; i < nightChartTotal.size(); i++) {
			chart2 = new Chart();
			List<CheckRoom> nightCheckRoom = nightChartTotal.get(i).getCheckRoom();
			List<CheckRoom> moodNightCheckRoom = moodnightChartTotal.get(i).getCheckRoom();
			Integer nigthSum = new Integer(0);
			Integer moodNigthSum = new Integer(0);
			for (int j = 0; j < nightCheckRoom.size(); j++) {
				if (nightCheckRoom.get(j).getYes().equals("1")) {
					nigthSum += 1;
				}
			}
			for (int j = 0; j < moodNightCheckRoom.size(); j++) {
				if (moodNightCheckRoom.get(j).getYes().equals("1")) {
					moodNigthSum += 1;
				}
			}
			chart2.setName(nightChartTotal.get(i).getName().get(0));
			chart2.setNightRate(((double) nigthSum / nightCheckRoom.size()) * 100);
			chart2.setMoodNightRate(((double) moodNigthSum / nightCheckRoom.size()) * 100);
			cList.add(chart2);
		}
		return cList;
	}

}
