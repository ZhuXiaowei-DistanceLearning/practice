package cn.hlgzj.pojo;

public class RoomTime {
	private String id;

	private String roomid;

	private String night;

	private String moodmight;

	private String today;

	private Room room;

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid == null ? null : roomid.trim();
	}

	public String getNight() {
		return night;
	}

	public void setNight(String night) {
		this.night = night == null ? null : night.trim();
	}

	public String getMoodmight() {
		return moodmight;
	}

	public void setMoodmight(String moodmight) {
		this.moodmight = moodmight == null ? null : moodmight.trim();
	}

	public String getToday() {
		return today;
	}

	public void setToday(String today) {
		this.today = today == null ? null : today.trim();
	}
}