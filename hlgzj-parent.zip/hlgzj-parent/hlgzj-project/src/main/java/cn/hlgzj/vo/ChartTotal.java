package cn.hlgzj.vo;

import java.util.List;

import cn.hlgzj.pojo.CheckRoom;

public class ChartTotal {
	private List<CheckRoom> checkRoom;
	private List<String> name;

	public List<CheckRoom> getCheckRoom() {
		return checkRoom;
	}

	public void setCheckRoom(List<CheckRoom> checkRoom) {
		this.checkRoom = checkRoom;
	}

	public List<String> getName() {
		return name;
	}

	public void setName(List<String> name) {
		this.name = name;
	}

}
