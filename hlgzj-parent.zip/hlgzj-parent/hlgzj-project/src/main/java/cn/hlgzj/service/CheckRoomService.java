package cn.hlgzj.service;

import cn.hlgzj.vo.CheckRoom_Room_Vo;
import utils.E3Result;

public interface CheckRoomService {

	E3Result insertRecord(CheckRoom_Room_Vo vo, String times);

}
