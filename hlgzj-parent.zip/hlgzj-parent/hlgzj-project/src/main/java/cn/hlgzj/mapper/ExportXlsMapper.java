package cn.hlgzj.mapper;

import java.util.List;

import cn.hlgzj.pojo.Room;
import cn.hlgzj.vo.ExportXls;

public interface ExportXlsMapper {

	List<Room> findRoom();

	ExportXls findAllExportXls(String string, String today, String times);

}