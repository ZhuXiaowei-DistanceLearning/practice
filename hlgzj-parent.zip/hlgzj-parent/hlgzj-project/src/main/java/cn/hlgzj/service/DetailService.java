package cn.hlgzj.service;

import java.util.List;

import cn.hlgzj.vo.Detail_Vo;
import cn.hlgzj.vo.Question;
import pojo.EasyUIDataGridResult;

public interface DetailService {

	List<Detail_Vo> findAll(String roomid, String bc);

	List<Question> findErrorQuestion(String roomid, String bc);

}
