package cn.hlgzj.vo;

import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.Project;

public class Project_Check_Vo {
	private Project project;
	private Check check;

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Check getCheck() {
		return check;
	}

	public void setCheck(Check check) {
		this.check = check;
	}

}
