package cn.hlgzj.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.hlgzj.mapper.ProjectMapper;
import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.service.CheckService;
import cn.hlgzj.vo.Room_Check_Project_Vo;

@Controller
@RequestMapping("/check")
public class CheckController {
	@Autowired
	private CheckService checkService;
	@Autowired
	private ProjectMapper projectMapper;

	@RequestMapping("/PageQuery")
	public String PageQuery(HttpServletRequest request, HttpServletResponse response, String id, String bc) {
		Room_Check_Project_Vo list = checkService.PageQuery(id);
		List<Check> check = list.getCheckVo();
		Room room = list.getRoom();
		request.setAttribute("list", check);
		request.setAttribute("room", room);
		if (bc.equals("0")) {
			return "/night";
		} else if (bc.equals("1")) {
			return "/moodnight";
		}
		return null;
	}
}
