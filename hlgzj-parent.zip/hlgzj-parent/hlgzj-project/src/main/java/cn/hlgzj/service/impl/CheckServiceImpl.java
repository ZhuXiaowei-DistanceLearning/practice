package cn.hlgzj.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.hlgzj.mapper.CheckMapper;
import cn.hlgzj.mapper.RoomMapper;
import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.Room;
import cn.hlgzj.pojo.RoomCheckExample;
import cn.hlgzj.pojo.RoomExample;
import cn.hlgzj.service.CheckService;
import cn.hlgzj.vo.Room_Check_Project_Vo;

@Service
@Transactional
public class CheckServiceImpl implements CheckService {
	@Autowired
	private CheckMapper checkMapper;
	@Autowired
	private RoomMapper roomMapper;

	/**
	 * 查找题目和科室
	 */
	@Override
	public Room_Check_Project_Vo PageQuery(String id) {
		List<Check> check = checkMapper.findAll();
		RoomExample example = new RoomExample();
		example.createCriteria().andIdEqualTo(id);
		List<Room> room = roomMapper.selectByExample(example);
		RoomCheckExample roomCheckExample = new RoomCheckExample();
		roomCheckExample.createCriteria().andRoomIdEqualTo(room.get(0).getId());
		Room_Check_Project_Vo list = new Room_Check_Project_Vo();
		list.setCheckVo(check);
		list.setRoom(room.get(0));
		return list;
	}

}
