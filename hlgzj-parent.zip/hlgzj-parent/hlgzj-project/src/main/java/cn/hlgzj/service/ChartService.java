package cn.hlgzj.service;

import java.util.List;

import cn.hlgzj.vo.Chart;

public interface ChartService {

	List<Chart> findChart();

}
