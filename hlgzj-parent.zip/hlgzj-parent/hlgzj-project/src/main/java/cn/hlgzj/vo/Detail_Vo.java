package cn.hlgzj.vo;

import java.util.List;

import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.Circumstance;
import cn.hlgzj.pojo.Project;
import cn.hlgzj.pojo.Room;

public class Detail_Vo {
	private List<Check> check;
	private Circumstance circumstance;
	private Room room;
	private Project project;
	private List<CheckRoom> checkRoom;
	private Integer errorQuestion;

	public List<Check> getCheck() {
		return check;
	}

	public void setCheck(List<Check> check) {
		this.check = check;
	}

	public Circumstance getCircumstance() {
		return circumstance;
	}

	public void setCircumstance(Circumstance circumstance) {
		this.circumstance = circumstance;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public List<CheckRoom> getCheckRoom() {
		return checkRoom;
	}

	public void setCheckRoom(List<CheckRoom> checkRoom) {
		this.checkRoom = checkRoom;
	}

	public Integer getErrorQuestion() {
		return errorQuestion;
	}

	public void setErrorQuestion(Integer errorQuestion) {
		this.errorQuestion = errorQuestion;
	}

}
