package cn.hlgzj.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.helpers.DateTimeDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.hlgzj.mapper.CheckRoomMapper;
import cn.hlgzj.mapper.CircumstanceMapper;
import cn.hlgzj.mapper.RoomCheckMapper;
import cn.hlgzj.mapper.RoomTimeMapper;
import cn.hlgzj.pojo.Check;
import cn.hlgzj.pojo.CheckRoom;
import cn.hlgzj.pojo.Circumstance;
import cn.hlgzj.pojo.RoomCheck;
import cn.hlgzj.pojo.RoomTime;
import cn.hlgzj.pojo.RoomTimeExample;
import cn.hlgzj.service.CheckRoomService;
import cn.hlgzj.service.RoomService;
import cn.hlgzj.vo.CheckRoom_Room_Vo;
import pojo.EasyUIDataGridResult;
import utils.E3Result;

@Service
@Transactional
public class CheckRoomServiceImpl implements CheckRoomService {

	@Autowired
	private CheckRoomMapper checkRoomMapper;
	@Autowired
	private CircumstanceMapper circumstanceMapper;
	@Autowired
	private RoomTimeMapper roomTimeMapper;

	@Override
	public E3Result insertRecord(CheckRoom_Room_Vo vo, String times) {
		try {
			String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
			List<CheckRoom> list = vo.getCheckRoom();
			StringBuilder result = new StringBuilder();
			Integer grade = new Integer(0);
			/**
			 * 插入评价表内容
			 */
			for (CheckRoom checkRoom : list) {
				checkRoom.setTime(today);
				checkRoom.setBc(times);
				checkRoom.setRoomId(vo.getRoom().getId());
				grade += checkRoom.getGrade();
				System.out.println(checkRoom.getNote() != "");
				if (checkRoom.getNote() != "") {
					result.append(checkRoom.getNote() + ";");
				}
				checkRoomMapper.insert(checkRoom);
			}
			/**
			 * 情况统计
			 */
			Circumstance c = new Circumstance();
			c.setGrade(grade);
			c.setKf(100 - grade);
			c.setBegintime(today);
			c.setRoomid(vo.getRoom().getId());
			c.setTimes(Integer.parseInt(times));
			c.setResult(result.toString());
			circumstanceMapper.insert(c);
			/**
			 * 修改检查状态
			 */
			RoomTimeExample roomTimeExample = new RoomTimeExample();
			roomTimeExample.createCriteria().andRoomidEqualTo(vo.getRoom().getId()).andTodayEqualTo(today);
			List<RoomTime> roomTimeList = roomTimeMapper.selectByExample(roomTimeExample);
			RoomTime roomTime = roomTimeList.get(0);
			if (Integer.parseInt(times) == 0) {
				roomTime.setNight("1");
			} else if (Integer.parseInt(times) == 1) {
				roomTime.setMoodmight("1");
			}
			roomTimeMapper.updateByPrimaryKey(roomTime);
			return E3Result.build(200, "提交成功!");
		} catch (Exception e) {
			return E3Result.build(400, "提交失败!");
		}
	}
}
