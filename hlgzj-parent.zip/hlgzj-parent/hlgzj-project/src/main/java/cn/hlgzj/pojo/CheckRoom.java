package cn.hlgzj.pojo;

public class CheckRoom {
    private String bc;

    private String yes;

    private String note;

    private String pic;

    private String time;

    private Integer grade;

    private String roomId;

    private String checkId;

    public String getBc() {
        return bc;
    }

    public void setBc(String bc) {
        this.bc = bc == null ? null : bc.trim();
    }

    public String getYes() {
        return yes;
    }

    public void setYes(String yes) {
        this.yes = yes == null ? null : yes.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic == null ? null : pic.trim();
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time == null ? null : time.trim();
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId == null ? null : roomId.trim();
    }

    public String getCheckId() {
        return checkId;
    }

    public void setCheckId(String checkId) {
        this.checkId = checkId == null ? null : checkId.trim();
    }
}