package zxw.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import zxw.pojo.User;

public class UserDao {
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;

	public void register(String username, String password) {
		try {
			conn = DBUtils.getConnection();
			String sql = "insert into zobie values (? , ?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setString(2, password);
			int i = stmt.executeUpdate();
		} catch (Exception e) {
			throw new RuntimeException("����ʧ��");
		} finally {
			DBUtils.closeAll(rs, stmt, conn);
		}
	}

	public User login(String username, String password) {
		User u = null;
		try {
			conn = DBUtils.getConnection();
			String sql = "select * from zobie where username = ? AND password = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			if (rs.next()) {
				u = new User();
				u.setUsername(rs.getString(1));
				u.setPassword(rs.getString(2));
			}
		} catch (Exception e) {
			throw new RuntimeException("����ʧ��");
		} finally {
			DBUtils.closeAll(rs, stmt, conn);
		}
		return u;
	}
}
