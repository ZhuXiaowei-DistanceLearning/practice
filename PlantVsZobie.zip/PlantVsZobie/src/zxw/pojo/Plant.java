package zxw.pojo;

import java.awt.Image;

public abstract class Plant {
	public Image plantImage;
	public Image bulletImage;
	public Image peaBullet;
	public Image TwoBullet;
	public Image SunBullet;
	public int offset;
	public int times;

	public abstract Image getPlantImage();

	public abstract Image getPeaBullet();

	public abstract Image getTwobulletImg();

	public abstract Image getSunBullet();

	public abstract Image getBulletImage();

	public abstract boolean doCollision(int bulletX, int bulletY, int zombieX,
			int zombieY);

}
