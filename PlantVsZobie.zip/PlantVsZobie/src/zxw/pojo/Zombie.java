package zxw.pojo;

import java.awt.Image;

public class Zombie {
	public Image img;
	public int fps;
		
	public Zombie(Image img, int fps) {
			super();
			this.img = img;
			this.fps = fps;
	}
		
		
	
}
