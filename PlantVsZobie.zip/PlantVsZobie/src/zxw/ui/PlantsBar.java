package zxw.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import zxw.common.ConstantData;
import zxw.common.PlantType;
import zxw.entity.SeedCard;
import zxw.util.ImageUtil;

public class PlantsBar implements ConstantData {
	private int plantSum;
	private Image seedBank;
	private SeedCard[] cards;
	private int lights;
	private int n = 1;
	private Font lightFont;

	// ����ֲ�������б�
	public PlantsBar() {
		seedBank = ImageUtil.loadImage("SeedBank.png");
		// allSeedImg = ImageUtil.loadImage("allseeds.png");
		plantSum = 7;
		cards = new SeedCard[plantSum];
		for (int i = 0; i < plantSum; ++i) {
			cards[i] = new SeedCard(new Point(SEED_OFFSET + ADD_SUN_OFFSET
					+ (CARD_WIDTH + CARD_GAP_W) * i, TOP_OFFSET), new Point(i,
					0));
		}
		lightFont = new Font(Font.DIALOG, Font.BOLD, 15);
		lights = 200;
	}

	public void seedUpdate(int y) {
		for (SeedCard sc : cards) {
			int x = (int) sc.getCoord().getX();
			sc.seedUpdate(x, y);
		}
	}

	// ��ȡ��ѡֲ������
	public PlantType selectedPlant(Point pos) {
		if ((pos.x > SEED_OFFSET + ADD_SUN_OFFSET)
				&& (pos.x < SEED_OFFSET + ADD_SUN_OFFSET
						+ seedBank.getWidth(null)) && (pos.y > TOP_OFFSET)
				&& (pos.y < TOP_OFFSET + seedBank.getHeight(null))) {
			for (SeedCard sc : cards) {
				if (sc.mouseIn(pos.x, pos.y, sc.getPlantType().toString(),
						lights)) {
					PlantType type = sc.getPlantType();
					if (type.toString() == "SunFlower") {
						seedUpdate(2);
						lights -= 50;
					} else if (type.toString() == "SingleBullet") {
						seedUpdate(1);
						lights -= 100;
					} else if (type.toString() == "Cherry") {
						seedUpdate(3);
						lights -= 150;
					} else if (type.toString() == "SmallStone") {
						seedUpdate(4);
						lights -= 50;
					} else if (type.toString() == "Mine") {
						seedUpdate(5);
						lights -= 25;
					} else if (type.toString() == "ColdBullet") {
						seedUpdate(6);
						lights -= 175;
					} else if (type.toString() == "Eat") {
						seedUpdate(7);
						lights -= 150;
					}
					return sc.getPlantType();
				}
			}
			return PlantType.NONE;
		} else {
			return PlantType.NONE;
		}
	}

	public void draw(Graphics g) {
		g.drawImage(seedBank, ConstantData.SEED_OFFSET, 0, null);
		for (SeedCard sc : cards) {
			int x = (int) sc.getCoord().getX();
			sc.draw(g, x);
		}
		// cards[0].draw(g);
		// cards[1].draw(g);
		// ��������ֵ
		g.setColor(Color.black);
		g.setFont(lightFont);
		g.drawString(String.valueOf(lights), SEED_OFFSET
				+ ADD_SUN_COUNT_X_OFFSET, ADD_SUN_COUNT_y_OFFSET);

	}

	public void drawSun(Graphics g, int y, int x, int z, int m) {
		Image sun = ImageUtil.loadImage("Sun.gif");
		if (n == m) {
			lights += 50;
			n++;
		}
		if (z == 1) {
			g.drawImage(null, x, y, null);
		} else {
			g.drawImage(sun, x, y, null);
		}
	}
}
