package zxw.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.text.GapContent;

import zxw.common.ConstantData;
import zxw.util.ImageUtil;

public class MenuFrame {
	private MenuPanel menuPanel;
	private JPanel panel;
	private CardLayout layout;
	private GamePlay gamePlay;
	private static Anmation in;
	private BeginAnimate animate;

	public MenuFrame() {
		JFrame frame = new JFrame();
		frame.setTitle("ֲ���ս��ʬ");
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new JPanel();
		menuPanel = new MenuPanel(this);
		gamePlay = new GamePlay();
		layout = new CardLayout();
		animate = new BeginAnimate();
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		//
		panel.setLayout(layout);
		panel.setPreferredSize(new Dimension(ConstantData.WIDTH,
				ConstantData.HEIGHT)); // ����panel����ĸߣ���
		panel.add(menuPanel, "menu");
		panel.add(gamePlay, "play");
		panel.add(animate, "animate");
		// �õ���Ļ�ĳߴ�
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension dim = tk.getScreenSize();
		frame.setLocation((dim.width - ConstantData.WIDTH) / 2,
				(dim.height - ConstantData.HEIGHT) / 2);
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		animation();
		final Timer timer = new Timer("ֲ���ս��ʬ");
		long waitTime = 2000;
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				new MenuFrame();
			}
		}, waitTime);
	}

	public void switchToGame() {
		layout.show(panel, "animate"); // ��ʾ��Ϸ���棨�ڶ�����Ƭ�� Ҳ��layout.next(panel);
		animate.startGame();
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				animate.stopGame();
				layout.show(panel, "play"); // ��ʾ��Ϸ���棨�ڶ�����Ƭ��
											// Ҳ��layout.next(panel);
				gamePlay.startGame();
			}
		}, 1500);
	}

	public static void animation() {
		final JFrame jf = new JFrame();
		in = new Anmation();
		jf.setSize(815, 649);
		jf.setLocationRelativeTo(null);
		jf.setResizable(false);
		jf.setUndecorated(true);
		jf.setBackground(Color.black);
		jf.setTitle("ֲ���ս��ʬ");
		// jf.getContentPane().setBackground(Color.black);
		// jf.getContentPane().setVisible(false);
		jf.add(in);
		jf.setVisible(true);
		final Timer timer = new Timer("ֲ���ս��ʬ");
		long waitTime = 2000;
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				jf.dispose();
			}
		}, waitTime);
	}
}

class Anmation extends JPanel {
	Image background;
	private Image logo;

	public Anmation() {
		background = ImageUtil
				.loadImage("5d3c670e7bec54e7aa9aac64be389b504fc26a5e.jpg");
		logo = ImageUtil.loadImage("PartnerLogo.png");
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(background, 107, 80, null);
		g.drawImage(logo, 710, 554, null);
	}
}
