package zxw.ui;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;

import zxw.common.ConstantData;
import zxw.common.PlantType;
import zxw.entity.SunFlowerPlant;
import zxw.pojo.Plant;
import zxw.util.ImageUtil;

public class BeginAnimate extends JPanel implements Runnable {
	private Image grasslandImage;
	private Thread gameThread;
	private Graphics graphic;
	private int x = 0;
	private Image gameImage = null;
	private Image glass = null;
	private Image glass2 = null;
	private Image glass3 = null;
	private Image glass4 = null;
	private Image glass5 = null;
	private Image floor = null;
	private Image floor2 = null;
	private Image floor3 = null;
	private Image floor4 = null;
	private Image floor5 = null;
	private PlantType selectedPlantType = null;
	private int dx1, dy1, dx2, dy2; // Ŀ����ε�һ������ڶ����ǵ�X��Y����
	private int sx1, sy1, sx2, sy2; // Դ���ε�һ������ڶ����ǵ�X��Y����

	public BeginAnimate() {
		super();
		dx2 = sx2 = 200; // ��ʼ��ͼ���С
		dy2 = sy2 = 520; // ��ʼ��ͼ���С
		grasslandImage = ImageUtil
				.loadImage("\\interface\\background1unsodded.jpg");
		glass = ImageUtil.loadImage("\\interface\\SodRollCap.png");
		glass2 = ImageUtil.loadImage("\\interface\\SodRollCap.png");
		glass3 = ImageUtil.loadImage("\\interface\\SodRollCap.png");
		glass4 = ImageUtil.loadImage("\\interface\\SodRollCap.png");
		glass5 = ImageUtil.loadImage("\\interface\\SodRollCap.png");

		floor = ImageUtil.loadImage("\\interface\\sod1row.png");
		floor2 = ImageUtil.loadImage("\\interface\\sod1row.png");
		floor3 = ImageUtil.loadImage("\\interface\\sod1row.png");
		floor4 = ImageUtil.loadImage("\\interface\\sod1row.png");
		floor5 = ImageUtil.loadImage("\\interface\\sod1row.png");
		selectedPlantType = PlantType.NONE;
		gameThread = new Thread(this);
	}

	@Override
	public void run() {
		while (true) {
			x += 1;
			gameRender();
			paintScreen();
		}
	}

	public void gameRender() {
		if (gameImage == null) {
			gameImage = this.createImage(this.getWidth(), this.getHeight()); // ����panel��IMAGE����С������
			if (gameImage == null) {
				System.out.println("gameImage is null");
				return;
			} else {
				graphic = gameImage.getGraphics(); // ���һ��gameImage��Graphics�����ģ����ڻ�ͼ
			}

		}
		// ��ʾgameImage�ϵ�ͼ��
		graphic.drawImage(grasslandImage, 0, 0, getWidth(), getHeight(),
				ConstantData.LEFT_OFFSET, 0, ConstantData.LEFT_OFFSET
						+ getWidth(), getHeight(), null);

		graphic.drawImage(floor, 33, 70, 100 + x, 5000, 0, 0, 100 + x, 5000,
				null);

		graphic.drawImage(floor2, 33, 170, 100 + x, 5000, 0, 0, 100 + x, 5000,
				null);
		graphic.drawImage(floor3, 33, 270, 100 + x, 5000, 0, 0, 100 + x, 5000,
				null);
		graphic.drawImage(floor4, 30, 370, 100 + x, 5000, 0, 0, 100 + x, 5000,
				null);
		graphic.drawImage(floor5, 27, 470, 100 + x, 5000, 0, 0, 100 + x, 5000,
				null);

		graphic.drawImage(glass2, 33 + x, 100, null);
		graphic.drawImage(glass2, 33 + x, 200, null);
		graphic.drawImage(glass3, 33 + x, 300, null);
		graphic.drawImage(glass4, 27 + x, 400, null);
		graphic.drawImage(glass5, 24 + x, 500, null);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}

	public void startGame() {
		gameThread.start();
	}

	public void stopGame() {
		gameThread.stop();
	}

	public void paintScreen() {
		Graphics g;
		try {
			g = this.getGraphics(); // ���panel��Graphics�����ģ����ڻ�ͼ
			if (g != null && gameImage != null) {
				g.drawImage(gameImage, 0, 0, null); // ����Ļ����ʾpanel��ͼ��
			}
			Toolkit.getDefaultToolkit().sync(); // sync the display on some
												// systems Synchronizes this
												// toolkit's graphics state.
												// Some window systems may do
												// buffering of graphics events.
			g.dispose();
		} catch (Exception e) {
			System.out.println("Graphics error: " + e);
		}
	}
}
