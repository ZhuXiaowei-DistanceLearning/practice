package zxw.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRootPane;
import javax.swing.JTextField;

import zxw.common.ConstantData;
import zxw.pojo.User;
import zxw.util.ImageUtil;
import zxw.util.UserDao;

public class MenuPanel extends JPanel {
	private Image bg;
	private Image OverRegister;
	private Image LeaveRegister;
	private Image Overlogin;
	private Image Leavelogin;
	private MenuFrame menuFrame;

	public MenuPanel(MenuFrame menuFrame) {
		this.menuFrame = menuFrame;
		bg = ImageUtil.loadImage("Logo.jpg");
		Overlogin = ImageUtil.loadImage("btn_play.gif");
		Leavelogin = ImageUtil.loadImage("btn_play2.gif");
		OverRegister = ImageUtil.loadImage("btn_register.gif");
		LeaveRegister = ImageUtil.loadImage("btn_register2.gif");
		setLayout(null);
		Cursor cursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
		// ��¼
		JButton loginJB = new JButton();
		loginJB.setRolloverIcon(new ImageIcon(Leavelogin));
		loginJB.setCursor(cursor);
		loginJB.setFocusable(false);
		loginJB.setBorder(null);
		loginJB.setIcon(new ImageIcon(Overlogin));
		loginJB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});
		// ע��
		JButton registerJB = new JButton();
		registerJB.setFocusable(false);
		registerJB.setToolTipText("��ʼ��Ϸ��");
		registerJB.setBorder(null);
		// //����buttonΪ͸��:setContentAreaFilled(false) �� setBorderPainted(false)��
		registerJB.setCursor(cursor);
		registerJB.setRolloverIcon(new ImageIcon(LeaveRegister));
		registerJB.setPressedIcon(new ImageIcon(LeaveRegister));// ����갴��ʱ����ʾ
		registerJB.setIcon(new ImageIcon(OverRegister));

		registerJB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				register();
			}

		});
		add(registerJB);
		add(loginJB);

		registerJB.setBounds(300, 430, OverRegister.getWidth(null),
				LeaveRegister.getHeight(null));
		loginJB.setBounds(300, 480, OverRegister.getWidth(null),
				LeaveRegister.getHeight(null));
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(bg, 0, 0, getWidth(), getHeight(), null);
	}

	private void register() {
		final JFrame jf = new JFrame();
		JButton btn;
		final JTextField jtf;
		final JPasswordField jpwd;
		JLabel jl1, jl2;
		JPanel jp1, jp2, jp3;
		btn = new JButton("ע��");
		// jb2 = new JButton("ȡ��");

		jtf = new JTextField(10);
		jpwd = new JPasswordField(10);

		jl1 = new JLabel("�û�����");
		jl2 = new JLabel("��    �룺");

		jp1 = new JPanel();
		jp2 = new JPanel();
		jp3 = new JPanel();
		// ���ò��ֹ�����
		jf.setLayout(new GridLayout(3, 1, 5, 5));
		// �������
		jp1.add(jl1);
		jp1.add(jtf);

		jp2.add(jl2);
		jp2.add(jpwd);

		jp3.add(btn);

		jf.add(jp1);
		jf.add(jp2);
		jf.add(jp3);
		// ���ô�������
		jf.setTitle("ע�����");
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setSize(280, 180);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setVisible(true);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				UserDao user = new UserDao();
				user.register(jtf.getText().trim(), jpwd.getText().trim());
				jf.dispatchEvent(new WindowEvent(jf, WindowEvent.WINDOW_CLOSING));
			}
		});

	}

	private void login() {
		final JFrame jf = new JFrame();
		JButton btn;
		final JTextField jtf;
		final JPasswordField jpwd;
		JLabel jl1, jl2;
		JPanel jp1, jp2, jp3;
		btn = new JButton("��¼");
		// jb2 = new JButton("ȡ��");

		jtf = new JTextField(10);
		jpwd = new JPasswordField(10);

		jl1 = new JLabel("�û�����");
		jl2 = new JLabel("��    �룺");

		jp1 = new JPanel();
		jp2 = new JPanel();
		jp3 = new JPanel();
		// ���ò��ֹ�����
		jf.setLayout(new GridLayout(3, 1, 5, 5));
		// �������
		jp1.add(jl1);
		jp1.add(jtf);

		jp2.add(jl2);
		jp2.add(jpwd);

		jp3.add(btn);

		jf.add(jp1);
		jf.add(jp2);
		jf.add(jp3);
		// ���ô�������
		jf.setTitle("��¼����");
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setSize(280, 180);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setVisible(true);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				UserDao user = new UserDao();
				User u = user
						.login(jtf.getText().trim(), jpwd.getText().trim());
				if (u != null) {
					page();
				}
				jf.dispatchEvent(new WindowEvent(jf, WindowEvent.WINDOW_CLOSING));
			}
		});

	}

	private void page() {
		final JFrame jf = new JFrame("��ʼ��Ϸ");
		Image startLeaveImg = ImageUtil.loadImage("start_leave.png");
		Container contentPane = jf.getContentPane();
		contentPane.setLayout(new BorderLayout());
		jf.setLayout(new BorderLayout());
		jf.setSize(500, 500);
		jf.setUndecorated(true);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Cursor cursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR); // ���ù��Ϊ����
		JButton startBtn = new JButton();
		startBtn.setFocusable(false);
		startBtn.setBorder(null);
		startBtn.setBorderPainted(false);
		startBtn.setCursor(cursor);
		startBtn.setIcon(new ImageIcon(startLeaveImg));
		startBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jf.dispatchEvent(new WindowEvent(jf, WindowEvent.WINDOW_CLOSING));
				menuFrame.switchToGame();
			}
		});
		// jp.add(startBtn);
		startBtn.setBounds(0, 0, startLeaveImg.getHeight(null),
				startLeaveImg.getWidth(null));
		jf.getContentPane().add(startBtn, BorderLayout.CENTER);
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);

	}
}
