package zxw.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;

import zxw.common.ConstantData;
import zxw.common.PlantType;
import zxw.util.ImageUtil;

public class SeedCard implements ConstantData {

	private float percent;
	private float percent2;
	private float percent3;
	private float percent4;
	private float percent5;
	private float percent6;
	private float percent7;

	private static Image allSeed = ImageUtil.loadImage("allseeds.png");
	private static Image allSeedDark = ImageUtil.loadImage("allseeds_dark.png");

	private Point pos;
	private Point coord;
	private int a = 960, b = 960, c = 1200, d = 1320, e = 1440, f = 1560,
			g = 1680;
	private PlantType plantType;

	public PlantType getPlantType() {
		return plantType;
	}

	private int freezingSeconds;
	private int count;

	public SeedCard(Point pos, Point coord) {
		this.pos = pos;
		this.coord = coord;
		plantType = seedMap[coord.y][coord.x]; // �õ���Ӧ��ֲ�����Ͷ���
		percent = .5f;
		percent2 = .5f;
		percent3 = .5f;
		percent4 = .5f;
		percent5 = .5f;
		percent6 = .5f;
		percent7 = .5f;

		initFreezingTime(plantType); // ����ÿ��ֲ�ﲻ����ʱ��
		count = 0;
	}

	public boolean mouseIn(int x, int y, String name, int lights) {
		if ((x > pos.x) && (x < pos.x + CARD_WIDTH) && (y > pos.y)
				&& (y < pos.y + CARD_HEIGHT)) {
			System.out.println(lights);
			if ((x > pos.x) && (x < pos.x + CARD_WIDTH) && (y > pos.y)
					&& (y < pos.y + CARD_HEIGHT)) {
				if (name == "SunFlower" && lights >= 50) {
					if (b == 960) {
						return true;
					} else {
						return false;
					}
				} else if (name == "SingleBullet" && lights >= 100) {
					if (a == 960) {
						return true;
					} else {
						return false;
					}
				} else if (name == "Cherry" && lights >= 150) {
					if (c == 1200) {
						return true;
					} else {
						return false;
					}
				} else if (name == "SmallStone" && lights >= 50) {
					if (d == 1320) {
						return true;
					} else {
						return false;
					}
				} else if (name == "Mine" && lights >= 25) {
					if (e == 1440) {
						return true;
					} else {
						return false;
					}
				} else if (name == "ColdBullet" && lights >= 175) {
					if (f == 1560) {
						return true;
					} else {
						return false;
					}
				} else if (name == "Eat" && lights >= 150) {
					if (g == 1680) {
						return true;
					} else {
						return false;
					}
				}
			}
		}
		return false;
	}

	// ����ֲ�ﶳ��ʱ��
	private void initFreezingTime(PlantType plantType) {
		switch (plantType) {
		case SunFlower:
			freezingSeconds = 8;
			break;
		case SingleBullet:
			freezingSeconds = 8;
			break;
		case Cherry:
			freezingSeconds = 10;
			break;
		case SmallStone:
			freezingSeconds = 11;
			break;
		case Mine:
			freezingSeconds = 12;
			break;
		case ColdBullet:
			freezingSeconds = 13;
			break;
		case Eat:
			freezingSeconds = 14;
			break;
		case DoubBullet:
			freezingSeconds = 15;
			break;
		}

	}

	public void reset() {
		count = 0;
	}

	// �����ӳ٣�����Ŀ���Դͼ����ʼ����Y�ĵ�����
	public void seedUpdate(int x, int y) {
		if (x == 0) {
			a++;
		} else if (x == 1) {
			b++;
		} else if (x == 2) {
			c++;
		} else if (x == 3) {
			d++;
		} else if (x == 4) {
			e++;
		} else if (x == 5) {
			f++;
		} else if (x == 6) {
			g++;
		}
		percent = ((float) a) / (freezingSeconds * DEFAULT_FPS);
		percent2 = ((float) b) / (freezingSeconds * DEFAULT_FPS);
		percent3 = ((float) c) / (freezingSeconds * DEFAULT_FPS);
		percent4 = ((float) d) / (freezingSeconds * DEFAULT_FPS);
		percent5 = ((float) e) / (freezingSeconds * DEFAULT_FPS);
		percent6 = ((float) f) / (freezingSeconds * DEFAULT_FPS);
		percent7 = ((float) g) / (freezingSeconds * DEFAULT_FPS);
		// System.out.println("percent: " + percent);
		if (a >= freezingSeconds * DEFAULT_FPS) {
			a = freezingSeconds * DEFAULT_FPS;
			if (y == 1) {
				a = 0;
			}
		}
		if (b >= freezingSeconds * DEFAULT_FPS) {
			b = freezingSeconds * DEFAULT_FPS;
			if (y == 2) {
				b = 0;
			}
		}
		if (c >= freezingSeconds * DEFAULT_FPS) {
			c = freezingSeconds * DEFAULT_FPS;
			if (y == 3) {
				c = 0;
			}
		}
		if (d >= freezingSeconds * DEFAULT_FPS) {
			d = freezingSeconds * DEFAULT_FPS;
			if (y == 4) {
				d = 0;
			}
		}
		if (e >= freezingSeconds * DEFAULT_FPS) {
			e = freezingSeconds * DEFAULT_FPS;
			if (y == 5) {
				e = 0;
			}
		}
		if (f >= freezingSeconds * DEFAULT_FPS) {
			f = freezingSeconds * DEFAULT_FPS;
			if (y == 6) {
				f = 0;
			}
		}
		if (g >= freezingSeconds * DEFAULT_FPS) {
			g = freezingSeconds * DEFAULT_FPS;
			if (y == 7) {
				g = 0;
			}
		}
	}

	// public int topH=0;
	public void draw(Graphics g, int x) {
		int picX = CARD_WIDTH * coord.x + CARD_GAP_W * coord.x; // �õ�Դͼ����ʼ����X
		int picY = CARD_HEIGHT * coord.y + CARD_GAP_H * coord.y; // �õ�Դͼ����ʼ����Y
		int topH = 0;
		if (x == 0) {
			topH = (int) (CARD_HEIGHT * percent);
		} else if (x == 1) {
			topH = (int) (CARD_HEIGHT * percent2);
		} else if (x == 2) {
			topH = (int) (CARD_HEIGHT * percent3);
		} else if (x == 3) {
			topH = (int) (CARD_HEIGHT * percent4);
		} else if (x == 4) {
			topH = (int) (CARD_HEIGHT * percent5);
		} else if (x == 5) {
			topH = (int) (CARD_HEIGHT * percent6);
		} else if (x == 6) {
			topH = (int) (CARD_HEIGHT * percent7);
		}
		/*
		 * if(topH<CARD_HEIGHT) topH+=1; else topH=0;
		 */
		// System.out.println("topH: "+topH);
		g.drawImage(allSeed, pos.x, pos.y, pos.x + CARD_WIDTH, pos.y + topH,
				picX, picY, picX + CARD_WIDTH, picY + topH, null);
		/*
		 * System.out.println("seed: "+ pos.x + " " + pos.y+ " " + (pos.x +
		 * CARD_WIDTH)+ " " + (pos.y + topH)+ " " + picX+ " " +picY+ " " + (picX
		 * + CARD_WIDTH)+ " " + (picY + topH)+"        "+percent);
		 */
		g.drawImage(allSeedDark, pos.x, pos.y + topH, pos.x + CARD_WIDTH, pos.y
				+ CARD_HEIGHT, picX, picY + topH, picX + CARD_WIDTH, picY
				+ CARD_HEIGHT, null);
	}

	public Point getCoord() {
		return coord;
	}

	public void setCoord(Point coord) {
		this.coord = coord;
	}

}
