package zxw.entity;

import java.awt.Image;

import zxw.common.ConstantData;
import zxw.pojo.Plant;
import zxw.util.ImageUtil;

//�㶹��
public class SingleBulletPlant extends Plant {

	public SingleBulletPlant() {
		plantImage = ImageUtil.loadImage("single_bullet_plant.gif");
		bulletImage = ImageUtil.loadImage("PotatoMine_light2.png");
		peaBullet = ImageUtil.loadImage("/Plants/PeaBulletHit.gif");
		offset = 0;
		times = 0;
	}

	public Image getPlantImage() {
		return plantImage;
	}

	public Image getBulletImage() {
		return bulletImage;
	}

	public Image getPeaBullet() {
		return peaBullet;
	}

	public boolean doCollision(int bulletX, int bulletY, int zombieX,
			int zombieY) {
		if (zombieX - bulletX > 0 && zombieX - bulletX < 10
				&& bulletY - zombieY < ConstantData.Normal_Zombie_HEIGHT) {
			System.out.println(zombieX - bulletX);
			System.out.println(zombieX - bulletX);
			System.out.println(bulletY - zombieY);
			times++;
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Image getTwobulletImg() {
		return bulletImage;
	}

	@Override
	public Image getSunBullet() {
		// TODO Auto-generated method stub
		return null;
	}
}
