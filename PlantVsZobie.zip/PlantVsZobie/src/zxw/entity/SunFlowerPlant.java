package zxw.entity;

import java.awt.Image;

import zxw.pojo.Plant;
import zxw.util.ImageUtil;

//���տ���
public class SunFlowerPlant extends Plant {

	public SunFlowerPlant() {
		plantImage = ImageUtil.loadImage("Plants\\SunFlower\\SunFlower.gif");
		bulletImage = ImageUtil.loadImage("Sun.gif");
		SunBullet = ImageUtil.loadImage("Sun2.png");
	}

	public Image getPlantImage() {
		return plantImage;
	}

	public Image getBulletImage() {
		return null;
	}

	public boolean doCollision(int bulletX, int bulletY, int zombieX,
			int zombieY) {
		return false;
	}

	@Override
	public Image getPeaBullet() {
		return null;
	}

	@Override
	public Image getTwobulletImg() {
		return null;
	}

	@Override
	public Image getSunBullet() {
		return SunBullet;
	}

}
