package zxw.common;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MoveRect extends Frame implements Runnable {
	private Rectangle hRect, vRect;
	private Image buffer;
	private Object o = new Object();

	public MoveRect() {
		super("MoveRect");

		hRect = new Rectangle(50, 0, 50, 50);// ˮƽ����˶���������
		vRect = new Rectangle(0, 50, 50, 50);// ��ֱ����˶���������

		setUndecorated(true);
		setLocation(500, 200);
		setSize(400, 400);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	// ����ѭ������(ʹ������һֱѭ�����˶�)
	public void circleDraw() {
	}

	// ���������ε�״̬
	public void drawRect(Graphics g, Rectangle r) {
		g.drawRect(r.x, r.y, r.width, r.height);
	}

	// ˫�������(��Ҫ�������)
	public void update(Graphics g) {
		buffer = createImage(getSize().width, getSize().height);

		if (buffer != null) {
			Graphics g2 = buffer.getGraphics();
			paint(g2);
			g2.dispose();
			g.drawImage(buffer, 0, 0, this);
		}

		else {
			paint(g);
		}
	}

	public void paint(Graphics g) {
		g.setColor(Color.GREEN);
		drawRect(g, hRect);
		g.setColor(Color.BLUE);
		drawRect(g, vRect);

		hRect.x = (int) (Math.random() * 351);
		vRect.y = (int) (Math.random() * 351);
	}

	public void run() {
		while (true) {
			stop();
			rePaint();
		}
	}

	// ͬ������rePaint
	public synchronized void rePaint() {
		repaint();
	}

	// ͬ������stop
	public synchronized void stop() {
		if (hRect.x <= 50 && vRect.y <= 50) {
			try {
				Thread.sleep(500);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		new Thread(new MoveRect()).start();
	}
}
