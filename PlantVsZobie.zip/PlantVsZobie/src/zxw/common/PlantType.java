package zxw.common;

import java.awt.Image;
import zxw.util.ImageUtil;

public enum PlantType {
	NONE(null), SunFlower(ImageUtil
			.loadImage("Plants\\SunFlower\\SunFlower.gif")), 
	SingleBullet(ImageUtil.loadImage("single_bullet_plant.gif")), 
	Cherry(null), SmallStone(null), Mine(null), ColdBullet(null), Eat(null), DoubBullet(
			null);

	private Image plantImg;

	PlantType(Image plantImg) {
		this.plantImg = plantImg;
	}

	public Image getPlantImg() {
		return plantImg;
	}

}
