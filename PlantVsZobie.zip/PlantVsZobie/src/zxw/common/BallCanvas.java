package zxw.common;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;

public class BallCanvas extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;
	private int h = 0;// �߶�
	private final float G = 9.8f;// �������ٶ�
	private final int D = 20;// С��ֱ��
	private float t = 0;// ʱ��
	private int x = 0;// ˮƽλ��
	private int v = 36;// ƽ���ٶ�

	public BallCanvas() {
		new Thread(this).start();
	}

	@Override
	public void run() {
		while (true) {
			t += 0.1;
			x = (int) (v * t);// ˮƽλ��
			h = (int) (G * t * t / 2);// ����߶�
			repaint();
			if (x > this.getWidth() || h > this.getHeight()) {
				t = 0;
				x = 0;
				h = 0;
			}

			try {
				Thread.sleep(85);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void paint(Graphics g) {
		// ���»�����Ļ
		// g.setColor(Color.white);
		// g.fillRect(0, 0, this.getWidth(), this.getHeight());

		g.setColor(Color.red);
		g.fillArc(x, h, D, D, 0, 360);

		g.setColor(Color.blue);
		g.fillArc(0, h, D, D, 0, 360);

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame = new JFrame("�ҵ�С��");
		Container con = frame.getContentPane();
		con.add(new BallCanvas(), BorderLayout.CENTER);
		frame.setPreferredSize(new Dimension(400, 400));
		frame.setVisible(true);
		frame.validate();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
	}

}
