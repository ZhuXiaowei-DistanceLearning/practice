package bos19.service;

import bos19.domain.Role;
import bos19.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/12.
 */
public interface RoleSerivce {
    public void save(Role model, String ids);

    public void pageQuery(PageBean pageBean);

    public List<Role> findAll();
}
