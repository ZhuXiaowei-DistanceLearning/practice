package bos19.service;

import bos19.domain.Decidedzone;
import bos19.utils.PageBean;

/**
 * Created by Administrator on 2017/6/8.
 */
public interface DecidedzoneService {
    public void save(Decidedzone decidedzone, String[] subareaid);

    public void pageQuery(PageBean pageBean);
}
