package bos19.service;

import bos19.domain.User;

/**
 * Created by Administrator on 2017/6/6.
 */
public interface UserSerivce {
    public User login(User user);

    public void editPassword(String password, String id);

    public void save(User model, String[] releIds);
}
