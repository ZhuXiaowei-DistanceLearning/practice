package bos19.service.impl;


import bos19.dao.UserDao;
import bos19.domain.Role;
import bos19.domain.User;
import bos19.service.UserSerivce;
import bos19.utils.MD5Utils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.Serializable;

/**
 * Created by Administrator on 2017/6/6.
 */
@Service
@Transactional
public class UserServiceImpl implements UserSerivce {
    @Resource
    private UserDao userDao;

    @Override
    public User login(User user) {
        String username = user.getUsername();
        String password = user.getPassword();
//        password = MD5Utils.md5(password);
        System.out.println("用户名：" + username + "," + "密码：" + password);
        return userDao.login(username, password);
    }

    @Override
    public void editPassword(String password, String id) {
        userDao.executeUpdate("editPassword", password, id);
    }

    @Override
    public void save(User model, String[] roleIds) {
        userDao.save(model);
        for (String roleId : roleIds) {
            Role role = new Role(roleId);
            model.getRoles().add(role);
        }
    }
}
