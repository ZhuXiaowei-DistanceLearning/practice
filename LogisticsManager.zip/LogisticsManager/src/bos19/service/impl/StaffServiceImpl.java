package bos19.service.impl;

import bos19.dao.StaffDao;
import bos19.domain.Staff;
import bos19.service.StaffService;
import bos19.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DeadlockLoserDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
@Service
@Transactional
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffDao staffDao;

    @Override
    public void save(Staff staff) {
        this.staffDao.save(staff);
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        staffDao.pageQuery(pageBean);
    }

    @Override
    public void deleteBatch(String ids) {
        String[] split = ids.split(",");
        for (String id : split) {
            this.staffDao.executeUpdate("staff.delete", id);
        }
    }

    @Override
    public void update(Staff model) {
        staffDao.update(model);
    }

    @Override
    public Staff findById(String id) {
        return this.staffDao.findById(id);
    }

    @Override
    public List<Staff> findListNoDelete() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Staff.class);
        detachedCriteria.add(Restrictions.ne("deltag", "1"));
        return staffDao.findByCriteria(detachedCriteria);
    }
}
