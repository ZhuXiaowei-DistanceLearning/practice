package bos19.service.impl;

import bos19.dao.RegionDao;
import bos19.domain.Region;
import bos19.service.RegionService;
import bos19.utils.PageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
@Service
@Transactional
public class RegionServiceImpl implements RegionService {
    @Resource
    private RegionDao regionDao;

    @Override
    public void saveBatach(List<Region> list) {
        for (Region region : list)
            regionDao.saveOrUpdate(region);
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        regionDao.pageQuery(pageBean);
    }

    @Override
    public List<Region> findAll() {
        return regionDao.findAll();
    }

    @Override
    public List<Region> findByQ(String q) {
        return null;
    }
}
