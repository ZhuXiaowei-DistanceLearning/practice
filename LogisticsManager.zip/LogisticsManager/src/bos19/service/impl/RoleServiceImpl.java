package bos19.service.impl;

import bos19.dao.RoleDao;
import bos19.domain.Function;
import bos19.domain.Role;
import bos19.service.RoleSerivce;
import bos19.utils.PageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/6/12.
 */
@Service
@Transactional
public class RoleServiceImpl implements RoleSerivce {
    @Resource
    private RoleDao roleDao;


    @Override
    public void save(Role model, String ids) {
        roleDao.save(model);
        String[] functionIds = ids.split(",");
        for (String fid : functionIds) {
            //角色关联权限
            Function function = new Function(fid);//托管
            model.getFunctions().add(function);
        }
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        roleDao.pageQuery(pageBean);
    }

    @Override
    public List<Role> findAll() {
        return roleDao.findAll();
    }
}
