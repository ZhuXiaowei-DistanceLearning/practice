package bos19.service.impl;

import bos19.dao.SubareaDao;
import bos19.domain.Subarea;
import bos19.service.SubareaService;
import bos19.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
@Service
@Transactional
public class SubareaServiceImpl implements SubareaService {
    @Resource
    private SubareaDao subareaDao;

    @Override
    public void save(Subarea subarea) {
        subareaDao.save(subarea);
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        subareaDao.pageQuery(pageBean);
    }

    /**
     * 查询没有关联到定区的分区
     *
     * @return
     */
    @Override
    public List<Subarea> findListNotAssciation() {
        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Subarea.class);
        detachedCriteria.add(Restrictions.isNull("decidedzone"));
        return subareaDao.findByCriteria(detachedCriteria);
    }

}
