package bos19.service.impl;

import bos19.dao.FunctionDao;
import bos19.domain.Function;
import bos19.domain.User;
import bos19.service.FunctionService;
import bos19.shiro.BOSRealm;
import bos19.utils.BOSContext;
import bos19.utils.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
@Service
@Transactional
public class FunctionServiceImpl implements FunctionService {
    @Autowired
    private FunctionDao functionDao;

    public void pageQuery(PageBean pageBean) {
        functionDao.pageQuery(pageBean);
    }

    @Override
    public List<Function> findMenu() {
        User user = BOSContext.getLoginUser();
        List<Function> list = null;
        if (user.getUsername().equals("a")) {
            list = functionDao.findAllMenu();
        } else {
            list = functionDao.findMenuByUserid(user.getId());
        }
        return list;
    }

    @Override
    public List<Function> findAll() {
        return functionDao.findAll();
    }

    @Override
    public void save(Function model) {
        if (model.getFunction() != null && model.getFunction().getId().equals("")) {
            model.setFunction(null);
        }
        functionDao.save(model);
    }


}
