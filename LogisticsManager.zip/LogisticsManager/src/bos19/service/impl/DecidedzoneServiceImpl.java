package bos19.service.impl;

import bos19.dao.DecidedzoneDao;
import bos19.dao.SubareaDao;
import bos19.domain.Decidedzone;
import bos19.domain.Subarea;
import bos19.service.DecidedzoneService;
import bos19.utils.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by Administrator on 2017/6/8.
 */
@Service
@Transactional
public class DecidedzoneServiceImpl implements DecidedzoneService {
    @Autowired
    private DecidedzoneDao decidedzoneDao;
    @Autowired
    private SubareaDao subareaDao;

    @Override
    public void save(Decidedzone decidedzone, String[] subareaid) {
        decidedzoneDao.save(decidedzone);
        for (String sid : subareaid) {
            Subarea subarea = subareaDao.findById(sid);
            subarea.setDecidedzone(decidedzone);
        }
    }

    @Override
    public void pageQuery(PageBean pageBean) {
        decidedzoneDao.pageQuery(pageBean);
    }
}
