package bos19.service;

import bos19.domain.Staff;
import bos19.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
public interface StaffService {
    public void save(Staff staff);

    public void pageQuery(PageBean pageBean);

    public void deleteBatch(String ids);

    public void update(Staff model);

    public Staff findById(String id);

    public List<Staff> findListNoDelete();
}
