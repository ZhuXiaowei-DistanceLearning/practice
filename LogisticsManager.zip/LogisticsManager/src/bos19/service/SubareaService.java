package bos19.service;

import bos19.domain.Subarea;
import bos19.utils.PageBean;

import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
public interface SubareaService {
    public void save(Subarea subarea);

    public void pageQuery(PageBean pageBean);

    public List<Subarea> findListNotAssciation();
}
