package bos19.web.action.base;

import bos19.crm.CustomerService;
import bos19.domain.Region;
import bos19.service.*;
import bos19.utils.PageBean;
import bos19.web.action.RoleAction;
import bos19.web.action.StaffAction;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.apache.poi.ss.formula.functions.T;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
public class BaseAction<T> extends ActionSupport implements ModelDriven<T> {
    @Autowired
    protected UserSerivce userSerivce;
    @Autowired
    protected RegionService regionService;
    @Autowired
    protected StaffService staffService;
    @Autowired
    protected SubareaService subareaService;
    @Autowired
    protected DecidedzoneService decidedzoneService;
    @Autowired
    protected CustomerService customerService;
    @Autowired
    protected FunctionService functionService;
    @Autowired
    protected RoleSerivce roleSerivce;

    protected PageBean pageBean = new PageBean();

    DetachedCriteria detachedCriteria = null;

    public void setPage(int page) {
        pageBean.setCurrentPage(page);
    }

    public void setRows(int rows) {
        pageBean.setPageSize(rows);
    }

    protected T model;

    @Override
    public T getModel() {
        return model;
    }

    public void writePageBean2Json(PageBean pageBean, String[] excludes) throws IOException {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setExcludes(excludes);
        //JSONArray:数组，集合
        //JSONObject:单个对象，Map
        System.out.println(pageBean);
        JSONObject jsonObject = JSONObject.fromObject(pageBean, jsonConfig);
        String json = jsonObject.toString();
        ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
        ServletActionContext.getResponse().getWriter().print(json);
    }

    public BaseAction() {
        ParameterizedType genericSuperclass = null;
        if (this.getClass().getGenericSuperclass() instanceof ParameterizedType) {
            genericSuperclass = (ParameterizedType) this.getClass().getGenericSuperclass();
        } else {
            genericSuperclass = (ParameterizedType) this.getClass().getSuperclass().getGenericSuperclass();
        }
        Type[] actualTypeArguments = genericSuperclass.getActualTypeArguments();
        Class<T> entityClass = (Class<T>) actualTypeArguments[0];
        detachedCriteria = DetachedCriteria.forClass(entityClass);
        pageBean.setDetachedCriteria(detachedCriteria);
        try {
            model = entityClass.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void writeList2Json(List list, String[] excludes) throws IOException {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setExcludes(excludes);
        //JSONArray:数组，集合
        //JSONObject:单个对象，Map
        JSONArray jsonObject = JSONArray.fromObject(list, jsonConfig);
        String json = jsonObject.toString();
        ServletActionContext.getResponse().setContentType("text/json;charset=UTF-8");
        ServletActionContext.getResponse().getWriter().print(json);
    }
}
