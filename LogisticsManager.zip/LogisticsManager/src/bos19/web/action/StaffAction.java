package bos19.web.action;

import bos19.domain.Staff;
import bos19.service.StaffService;
import bos19.utils.PageBean;
import bos19.web.action.base.BaseAction;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
@Controller
@Scope("prototype")
public class StaffAction extends BaseAction<Staff> {

    public String addStaff() {
        staffService.save(model);
        return "list";
    }

    public String pageQuery() throws IOException {
        staffService.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"currentPage", "detachedCriteria", "pageSize", "decidedzones", "subareas"});
        return NONE;
    }

    private String ids;

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String delete() {
        staffService.deleteBatch(ids);
        return "list";
    }

    public String editStaff() {
        Staff staff = staffService.findById(model.getId());
        staff.setName(model.getName());
        staff.setTelephone(model.getTelephone());
        staff.setStation(model.getStation());
        staff.setHaspda(model.getHaspda());
        staff.setStandard(model.getStandard());
        staffService.update(staff);
        return "list";
    }

    public String listajax() throws IOException {
        List<Staff> list = staffService.findListNoDelete();
        String[] excludes = new String[]{"decidedzones"};
        this.writeList2Json(list, excludes);
        return NONE;

    }
}
