package bos19.web.action;

import bos19.domain.Function;
import bos19.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
@Controller
@Scope("prototype")
public class FunctionAction extends BaseAction<Function> {
    public String pageQuery() throws IOException {
        String page = model.getPage();
        System.out.println(model.getPage());
        pageBean.setCurrentPage((Integer.parseInt(page)));
        functionService.pageQuery(pageBean);
        String[] excludes = new String[]{"function", "functions", "roles", "currentPage", "detachedCriteria", "pageSize"};
        this.writePageBean2Json(pageBean, excludes);
        return NONE;
    }

    public String listajax() throws IOException {
        List<Function> all = functionService.findAll();
        this.writeList2Json(all, new String[]{"function", "functions", "roles"});
        return NONE;
    }

    public String add() {
        functionService.save(model);
        return "list";
    }

    /**
     * 根据登录人查询对应的菜单数据
     *
     * @return
     * @throws IOException
     */
    public String findMenu() throws IOException {
        List<Function> list = functionService.findMenu();
        String[] excludes = new String[]{"functions", "function", "roles"};
        this.writeList2Json(list, excludes);
        return NONE;
    }
}
