package bos19.web.action;

import bos19.web.action.base.BaseAction;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.repository.ProcessDefinitionQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * 流程定义管理
 */
@Controller
@Scope("prototype")
public class ProcessDefinitionAction extends ActionSupport {
    //注入service
    @Autowired
    private RepositoryService repositoryService;

    /**
     * 查询最新版本流程定义列表数据
     */
    public String list() {
        ProcessDefinitionQuery query = repositoryService.createProcessDefinitionQuery();
        query.latestVersion();//查询最新版本
        query.orderByProcessDefinitionName().desc();//排序
        List<ProcessDefinition> list = query.list();//查询
        ActionContext.getContext().getValueStack().set("list", list);
        return "list";
    }
}
