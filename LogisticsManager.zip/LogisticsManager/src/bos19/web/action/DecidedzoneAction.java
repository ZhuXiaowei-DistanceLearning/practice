package bos19.web.action;

import bos19.domain.Decidedzone;
import bos19.web.action.base.BaseAction;
import crm.domain.Customer;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/8.
 */
@Controller
@Scope("prototype")
public class DecidedzoneAction extends BaseAction<Decidedzone> {
    private String[] subareaid;

    public String[] getSubareaid() {
        return subareaid;
    }

    public void setSubareaid(String[] subareaid) {
        this.subareaid = subareaid;
    }

    public String add() {
        decidedzoneService.save(model, subareaid);
        return "list";
    }

    public String pageQuery() throws IOException {
        decidedzoneService.pageQuery(pageBean);
        // 将PageBean对象转为json返回
        this.writePageBean2Json(pageBean, new String[]{"decidedzones",
                "subareas", "currentPage", "detachedCriteria", "pageSize"});
        return NONE;
    }

    public String findnoassocationCustomers() throws IOException {
        List<Customer> list = customerService.findnoassociationCustomers();
        this.writeList2Json(list,new String[]{"station","addres"});
        return NONE;
    }
}
