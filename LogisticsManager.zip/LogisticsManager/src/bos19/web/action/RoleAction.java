package bos19.web.action;

import bos19.domain.Region;
import bos19.domain.Role;
import bos19.web.action.base.BaseAction;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/12.
 */
@Controller
@Scope("prototype")
public class RoleAction extends BaseAction<Role> {
    private String ids;

    public String add() {
        roleSerivce.save(model, ids);
        return "list";
    }

    public String pageQuery() throws IOException {
        roleSerivce.pageQuery(pageBean);
        this.writePageBean2Json(pageBean, new String[]{"functions", "users", "currentPage", "detachedCriteria", "pageSize"});
        return NONE;
    }

    public String listajax() throws IOException {
        List<Role> list = roleSerivce.findAll();
        this.writeList2Json(list, new String[]{"functions", "users"});
        return NONE;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }
}
