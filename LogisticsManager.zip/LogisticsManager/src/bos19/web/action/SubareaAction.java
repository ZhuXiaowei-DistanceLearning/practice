package bos19.web.action;

import bos19.domain.Region;
import bos19.domain.Subarea;
import bos19.service.SubareaService;
import bos19.web.action.base.BaseAction;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
@Controller
@Scope("prototype")
public class SubareaAction extends BaseAction<Subarea> {

    public String add() {
        subareaService.save(model);
        return "list";
    }

    public String pageQuery() throws IOException {
        DetachedCriteria detachedCriteria2 = pageBean.getDetachedCriteria();
        String addresskey = model.getAddresskey();
        Region region = model.getRegion();
        if (StringUtils.isNotBlank(addresskey)) {
            detachedCriteria2.add(Restrictions.like("addressKey", addresskey));
        }
        if (region != null) {
            detachedCriteria2.createAlias("region", "r");
            String province = region.getProvince();
            String city = region.getCity();
            String district = region.getDistrict();
            if (StringUtils.isNotBlank(province)) {
                detachedCriteria2.add(Restrictions.like("r.province", "%" + province + "%"));
            }
            if (StringUtils.isNotBlank(city)) {
                detachedCriteria2.add(Restrictions.like("r.city", "%" + city + "%"));
            }
            if (StringUtils.isNotBlank(district)) {
                detachedCriteria2.add(Restrictions.like("r.district", "%" + district + "%"));
            }
        }
        subareaService.pageQuery(pageBean);
        String[] excludes = new String[]{"detachedCriteria", "currentPage",
                "pageSize", "subareas","decidedzone"};
        this.writePageBean2Json(pageBean, excludes);
        System.out.println(1);
        return NONE;
    }

    public String listajax() throws IOException {
        List<Subarea> list = subareaService.findListNotAssciation();
        String[] excludes = new String[]{"decidedzone", "region"};
        this.writeList2Json(list, excludes);
        return NONE;
    }
}
