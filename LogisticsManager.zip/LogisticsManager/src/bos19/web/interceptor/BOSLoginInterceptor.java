package bos19.web.interceptor;

import bos19.domain.User;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
import org.apache.struts2.ServletActionContext;

/**
 * Created by Administrator on 2017/6/6.
 */
public class BOSLoginInterceptor extends MethodFilterInterceptor {
    // 拦截方法
    protected String doIntercept(ActionInvocation invocation) throws Exception {
        User user = (User) ServletActionContext.getRequest().getSession()
                .getAttribute("user");
        if (user == null) {
            //未登录，跳转到登录页面
            Object obj = invocation.getAction();
            if(obj instanceof ActionSupport){
                ActionSupport action = (ActionSupport) obj;
                action.addActionError("请登录");
            }
            return "login";
        }
        return invocation.invoke();// 放行
    }
}
