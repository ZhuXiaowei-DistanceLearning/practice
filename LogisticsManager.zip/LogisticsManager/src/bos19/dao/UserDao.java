package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.User;

/**
 * Created by Administrator on 2017/6/6.
 */
public interface UserDao extends BaseDao<User> {
    public User login(String username, String password);

    public User findUserByUserName(String username);
}
