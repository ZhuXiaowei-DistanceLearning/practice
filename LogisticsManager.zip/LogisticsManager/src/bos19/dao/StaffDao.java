package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.Staff;

/**
 * Created by Administrator on 2017/6/6.
 */
public interface StaffDao extends BaseDao<Staff> {
}
