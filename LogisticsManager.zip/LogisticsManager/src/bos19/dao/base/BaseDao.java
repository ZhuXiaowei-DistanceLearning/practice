package bos19.dao.base;

import bos19.utils.PageBean;
import org.hibernate.criterion.DetachedCriteria;

import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
public interface BaseDao<T> {

    public void save(T t);

    public void update(T t);

    public void delete(T t);

    public void saveOrUpdate(T t);

    public T findById(java.io.Serializable id);

    public List<T> findAll();

    //通用修改方法
    public void executeUpdate(String queryName, Object... objects);

    public void pageQuery(PageBean pageBean);

    public List<T> findByCriteria(DetachedCriteria detachedCriteria);
}
