package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.Role;

/**
 * Created by Administrator on 2017/6/12.
 */
public interface RoleDao extends BaseDao<Role> {
}
