package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.Subarea;

/**
 * Created by Administrator on 2017/6/7.
 */
public interface SubareaDao extends BaseDao<Subarea> {
}
