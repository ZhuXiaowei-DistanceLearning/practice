package bos19.dao.impl;

import bos19.dao.SubareaDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.Region;
import bos19.domain.Subarea;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/7.
 */
@Repository
public class SubareaDaoImpl extends BaseDaoImpl<Subarea> implements SubareaDao {
}
