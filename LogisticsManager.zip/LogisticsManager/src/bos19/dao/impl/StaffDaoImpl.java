package bos19.dao.impl;

import bos19.dao.StaffDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.Staff;
import bos19.utils.PageBean;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/6.
 */
@Repository
public class StaffDaoImpl extends BaseDaoImpl<Staff> implements StaffDao {
}
