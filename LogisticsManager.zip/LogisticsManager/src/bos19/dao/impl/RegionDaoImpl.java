package bos19.dao.impl;

import bos19.dao.RegionDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.Region;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
@Repository
public class RegionDaoImpl extends BaseDaoImpl<Region> implements RegionDao {
    @Override
    public List<Region> findByQ(String q) {
        return null;
    }
}
