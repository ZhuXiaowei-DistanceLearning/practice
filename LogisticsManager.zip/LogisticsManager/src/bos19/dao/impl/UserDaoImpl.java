package bos19.dao.impl;

import bos19.dao.UserDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.User;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/6.
 */
@Repository
public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao {
    public User login(String username, String password) {
        List<User> list = this.getHibernateTemplate().find("FROM User where username = ? and password = ?", username, password);
        if (list.size() == 1) {
            return list.get(0);
        }
        return null;
    }

    @Override
    public User findUserByUserName(String username) {
        String hql = "FROM User u where u.username = ?";
        List<User> list = this.getHibernateTemplate().find(hql, username);
        if (list.size() == 1) {
            return list.get(0);
        }
        return null;
    }
}
