package bos19.dao.impl;

import bos19.dao.FunctionDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.Function;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
@Repository
public class FunctionDaoImpl extends BaseDaoImpl<Function> implements FunctionDao {
    /**
     * 根据用户id查询对应的权限
     *
     * @param id
     * @return
     */
    @Override
    public List<Function> findListByUserid(String userid) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.users u WHERE u.id = ?";
        return this.getHibernateTemplate().find(hql, userid);
    }

    @Override
    public List<Function> findAllMenu() {
        String hql = "FROM Function f WHERE f.generatemenu = '1' ORDER BY f.zindex DESC";
        return this.getHibernateTemplate().find(hql);
    }

    public List<Function> findMenuByUserid(String id) {
        String hql = "SELECT DISTINCT f FROM Function f LEFT OUTER JOIN f.roles r" +
                " LEFT OUTER JOIN r.users u WHERE u.id = ? AND f.generatemenu = '1' ORDER BY f.zindex DESC ";
        return this.getHibernateTemplate().find(hql, id);
    }
}
