package bos19.dao.impl;

import bos19.dao.DecidedzoneDao;
import bos19.dao.base.BaseDaoImpl;
import bos19.domain.Decidedzone;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/6/8.
 */
@Repository
public class DecidedzoneDaoImpl extends BaseDaoImpl<Decidedzone> implements DecidedzoneDao {
}
