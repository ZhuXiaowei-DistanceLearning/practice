package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.Region;

import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
public interface RegionDao extends BaseDao<Region> {
    public List<Region> findByQ(String q);
}
