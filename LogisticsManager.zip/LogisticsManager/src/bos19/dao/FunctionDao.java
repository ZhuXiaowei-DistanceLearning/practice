package bos19.dao;

import bos19.dao.base.BaseDao;
import bos19.domain.Function;

import java.util.List;

/**
 * Created by Administrator on 2017/6/11.
 */
public interface FunctionDao extends BaseDao<Function> {
    public List<Function> findListByUserid(String userid);

    public List<Function> findAllMenu();

    public List<Function> findMenuByUserid(String id);
}
