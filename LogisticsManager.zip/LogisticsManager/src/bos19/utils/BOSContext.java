package bos19.utils;

import bos19.domain.User;
import org.apache.struts2.ServletActionContext;


public class BOSContext {
	public static User getLoginUser(){
		return (User) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
	}
}
