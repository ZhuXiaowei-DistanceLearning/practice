package day37_spring.crm.coursetype.service;

import java.util.List;

import day37_spring.crm.coursetype.domain.CrmCourseType;
import day37_spring.crm.page.PageBean;


public interface CourseTypeService {
	
	/**
	 * 查询所有
	 * @return
	 */
	public List<CrmCourseType> findAll();

	/**
	 * 带有条件的查询所有
	 * @param courseType
	 * @return
	 */
	public List<CrmCourseType> findAll(CrmCourseType courseType);
	
	public PageBean<CrmCourseType> findAll(CrmCourseType courseType , int pageNum ,int pageSize);

	CrmCourseType findById(String courseTypeId);

	void addOrEdit(CrmCourseType courseType);


}
