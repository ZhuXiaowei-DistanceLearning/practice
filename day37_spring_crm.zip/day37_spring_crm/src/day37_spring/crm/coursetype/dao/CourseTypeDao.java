package day37_spring.crm.coursetype.dao;

import java.util.List;

import day37_spring.crm.coursetype.domain.CrmCourseType;

public interface CourseTypeDao {

	/**
	 * 查询所有
	 * 
	 * @return
	 */
	public List<CrmCourseType> findAll();

	/**
	 * 条件查询
	 * 
	 * @param condition
	 *            ，格式：" and ..? and ..."
	 * @param params
	 * @return
	 */
	public List<CrmCourseType> findAll(String condition, Object[] params);

	public int getTotalRecord(String condition, Object[] params);

	List<CrmCourseType> findAll(String condition, Object[] params, int startIndex, int pageSize);

	public CrmCourseType findById(String courseTypeId);

	public void saveOrUpdate(CrmCourseType courseType);

}
