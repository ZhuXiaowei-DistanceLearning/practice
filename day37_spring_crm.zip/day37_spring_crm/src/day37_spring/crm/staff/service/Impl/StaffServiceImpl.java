package day37_spring.crm.staff.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import day37_spring.crm.staff.dao.StaffDao;
import day37_spring.crm.staff.domain.CrmStaff;
import day37_spring.crm.staff.service.StaffService;
import day37_spring.crm.utils.MD5Utils;

public class StaffServiceImpl implements StaffService {
	private StaffDao staffDao;

	public void setStaffDao(StaffDao staffDao) {
		this.staffDao = staffDao;
	}

	@Override
	public CrmStaff login(CrmStaff staff) {
		String logginPwd = MD5Utils.getMD5Value(staff.getLoginPwd());
		return staffDao.find(staff.getLoginName(), staff.getLoginPwd());
	}

	@Override
	public List<CrmStaff> findAll() {
		return this.staffDao.findAll();
	}

	@Override
	public CrmStaff findId(String staffId) {
		return this.staffDao.findId(staffId);
	}

	@Override
	public void saveOrEdit(CrmStaff staff) {
		this.staffDao.saveOrEdit(staff);
	}

	@Override
	public List<CrmStaff> findAll(CrmStaff staff) {
		StringBuilder string = new StringBuilder();
		List<Object> paramsList = new ArrayList<Object>();
		if (StringUtils.isNotBlank(staff.getStaffName())) {
			System.out.println(staff.getStaffName());
			string.append(" and staffName like ?");
			paramsList.add("%" + staff.getStaffName() + "%");
		}
		if (StringUtils.isNotBlank(staff.getPost().getPostName())) {
			string.append(" and postName like ?");
			paramsList.add("%" + staff.getPost().getPostName() + "%");
		}
		if (StringUtils.isNotBlank(staff.getPost().getDepartment().getDepName())) {
			string.append(" and depName like ?");
			paramsList.add("%" + staff.getPost().getDepartment().getDepName() + "%");
		}
		String condition = string.toString();
		Object[] params = paramsList.toArray();
		return staffDao.findAll(condition, params);
	}
}
