package day37_spring.crm.staff.service;

import java.util.List;

import day37_spring.crm.staff.domain.CrmStaff;

public interface StaffService {
	/**
	 * 登录
	 * 
	 * @param staff
	 * @return
	 */
	public CrmStaff login(CrmStaff staff);

	/**
	 * 查找所有员工信息
	 */
	public List<CrmStaff> findAll();

	/**
	 * 查询员工id
	 */
	public CrmStaff findId(String staffId);

	/**
	 * 编辑和保存
	 */
	public void saveOrEdit(CrmStaff staff);

	public List<CrmStaff> findAll(CrmStaff staff);
}
