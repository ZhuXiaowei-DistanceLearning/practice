package day37_spring.crm.staff.web.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionChainResult;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import day37_spring.crm.department.domain.CrmDepartment;
import day37_spring.crm.department.service.DepartmentService;
import day37_spring.crm.staff.domain.CrmStaff;
import day37_spring.crm.staff.service.StaffService;

public class StaffAction extends ActionSupport implements ModelDriven<CrmStaff> {
	// 封装数据
	private CrmStaff staff = new CrmStaff();

	@Override
	public CrmStaff getModel() {
		return staff;
	}

	// 默认按照名称注入
	private StaffService staffService;
	private DepartmentService departmentService;

	public void setStaffService(StaffService staffService) {
		this.staffService = staffService;
	}

	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	/**
	 * 员工登录
	 * 
	 * @return
	 */
	public String login() {
		// 1 查询员工
		CrmStaff findStaff = staffService.login(staff);
		// 2 是否成功
		if (findStaff != null) {
			ActionContext.getContext().getSession().put("loginStaff", findStaff);
			return "success";
		}
		// 4 不成功
		this.addFieldError("", "用户名与密码不匹配");
		// * 请求转发显示
		return "login";
	}

	/**
	 * 显示首页
	 * 
	 * @return
	 */
	public String home() {
		return "home";
	}

	/**
	 * 查询所有
	 * 
	 * @return
	 */
	public String findAll() {
		List<CrmStaff> allStaff = staffService.findAll(staff);
		ActionContext.getContext().put("allStaff", allStaff);
		return "findAll";
	}

	/**
	 * 编辑和保存操作
	 * 
	 * @return
	 */
	public String saveOrEditUI() {
		if (StringUtils.isNotBlank(this.staff.getStaffId())) {
			CrmStaff findStaff = this.staffService.findId(this.staff.getStaffId());
			ActionContext.getContext().getValueStack().push(findStaff);
			// 2 查询所有部门
			List<CrmDepartment> allDepartment = departmentService.findAll();
			// * jsp页面通过“key”获得
			ActionContext.getContext().getValueStack().set("allDepartment", allDepartment);
		}
		return "saveOrEditUI";
	}

	public String saveOrEdit() {
		staffService.saveOrEdit(staff);
		return "saveOrEdit";
	}
}