package day37_spring.crm.staff.dao;

import java.util.List;

import day37_spring.crm.staff.domain.CrmStaff;

public interface StaffDao {
	public CrmStaff find(String loginName, String loginPwd);

	public List<CrmStaff> findAll();

	public CrmStaff findId(String id);

	public void saveOrEdit(CrmStaff staff);

	public List<CrmStaff> findAll(String condition, Object[] params);
}
