package day37_spring.crm.post.dao;

import java.util.List;

import day37_spring.crm.post.domain.CrmPost;

public interface PostDao {
	public List<CrmPost> findAll(); 
}
