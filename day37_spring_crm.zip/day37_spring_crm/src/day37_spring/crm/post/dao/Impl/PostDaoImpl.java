package day37_spring.crm.post.dao.Impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import day37_spring.crm.post.dao.PostDao;
import day37_spring.crm.post.domain.CrmPost;

public class PostDaoImpl extends HibernateDaoSupport implements PostDao{

	@Override
	public List<CrmPost> findAll() {
		return this.getHibernateTemplate().find("from CrmPost");
	}
	
}
