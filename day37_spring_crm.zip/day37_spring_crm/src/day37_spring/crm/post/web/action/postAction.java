package day37_spring.crm.post.web.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import day37_spring.crm.post.domain.CrmPost;
import day37_spring.crm.post.service.PostService;
import day37_spring.crm.post.service.Impl.PostServiceImpl;

public class postAction extends ActionSupport implements ModelDriven<CrmPost> {
	private CrmPost post;

	@Override
	public CrmPost getModel() {
		return post;
	}

	private PostService postService = new PostServiceImpl();

	public void setPostService(PostService postService) {
		this.postService = postService;
	}

	public String findAll() {
		List<CrmPost> allPost = postService.findAll();
		ActionContext.getContext().put("allPost", allPost);
		return "findAll";
	}
}
