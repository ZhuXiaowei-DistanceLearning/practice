package day37_spring.crm.post.domain;

import java.util.HashSet;
import java.util.Set;

import day37_spring.crm.department.domain.CrmDepartment;
import day37_spring.crm.staff.domain.CrmStaff;

public class CrmPost {
	private String postId;
	private String postName;

	private CrmDepartment department;
	private Set<CrmStaff> crmStaff = new HashSet<CrmStaff>();

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public String getPostName() {
		return postName;
	}

	public void setPostName(String postName) {
		this.postName = postName;
	}

	public CrmDepartment getDepartment() {
		return department;
	}

	public void setDepartment(CrmDepartment department) {
		this.department = department;
	}

	public Set<CrmStaff> getCrmStaff() {
		return crmStaff;
	}

	public void setCrmStaff(Set<CrmStaff> crmStaff) {
		this.crmStaff = crmStaff;
	}

}
