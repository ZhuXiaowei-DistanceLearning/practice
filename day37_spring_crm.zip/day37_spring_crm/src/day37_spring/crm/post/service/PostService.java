package day37_spring.crm.post.service;

import java.util.List;

import day37_spring.crm.post.domain.CrmPost;

public interface PostService {
	public List<CrmPost> findAll();
}
