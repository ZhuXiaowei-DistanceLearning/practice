package day37_spring.crm.post.service.Impl;

import java.util.List;

import day37_spring.crm.post.dao.PostDao;
import day37_spring.crm.post.domain.CrmPost;
import day37_spring.crm.post.service.PostService;

public class PostServiceImpl implements PostService {
	private PostDao postDao;

	public void setPostDao(PostDao postDao) {
		this.postDao = postDao;
	}

	@Override
	public List<CrmPost> findAll() {
		return this.postDao.findAll();
	}

}
