package day37_spring.crm.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Utils {
	public static String getMD5Value(String value) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("MD5");
			byte[] md5ValueByteArray = digest.digest(value.getBytes());
			BigInteger bigInteger = new BigInteger(1, md5ValueByteArray);
			return bigInteger.toString(16);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}
}
