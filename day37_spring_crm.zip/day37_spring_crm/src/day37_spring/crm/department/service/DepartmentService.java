package day37_spring.crm.department.service;

import java.util.List;

import day37_spring.crm.department.domain.CrmDepartment;

public interface DepartmentService {
	public List<CrmDepartment> findAll();
	
	public CrmDepartment findId(String depId);
}
