package day37_spring.crm.department.service.Impl;

import java.util.List;

import day37_spring.crm.department.dao.DepartmentDao;
import day37_spring.crm.department.domain.CrmDepartment;
import day37_spring.crm.department.service.DepartmentService;

public class DepartmentServiceImpl implements DepartmentService {
	private DepartmentDao departmentDao;

	public void setDepartmentDao(DepartmentDao departmentDao) {
		this.departmentDao = departmentDao;
	}

	@Override
	public List<CrmDepartment> findAll() {
		return departmentDao.findAll();
	}

	@Override
	public CrmDepartment findId(String depId) {
		return this.departmentDao.findId(depId);
	}

}
