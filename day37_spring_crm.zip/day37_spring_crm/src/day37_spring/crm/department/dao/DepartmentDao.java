package day37_spring.crm.department.dao;

import java.util.List;

import day37_spring.crm.department.domain.CrmDepartment;

public interface DepartmentDao {
	public List<CrmDepartment> findAll();
	
	public CrmDepartment findId(String depId);
}
