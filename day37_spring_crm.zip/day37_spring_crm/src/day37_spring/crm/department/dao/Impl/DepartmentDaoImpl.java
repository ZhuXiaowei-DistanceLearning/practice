package day37_spring.crm.department.dao.Impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import day37_spring.crm.department.dao.DepartmentDao;
import day37_spring.crm.department.domain.CrmDepartment;

public class DepartmentDaoImpl extends HibernateDaoSupport implements DepartmentDao {

	@Override
	public List<CrmDepartment> findAll() {
		return this.getHibernateTemplate().find("from CrmDepartment");
	}

	@Override
	public CrmDepartment findId(String depId) {
		return this.getHibernateTemplate().get(CrmDepartment.class, depId);
	}
}
