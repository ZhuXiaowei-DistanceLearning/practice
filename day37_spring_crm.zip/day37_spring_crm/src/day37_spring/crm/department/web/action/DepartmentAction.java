package day37_spring.crm.department.web.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import day37_spring.crm.department.domain.CrmDepartment;
import day37_spring.crm.department.service.DepartmentService;

public class DepartmentAction extends ActionSupport implements ModelDriven<CrmDepartment> {
	private CrmDepartment department = new CrmDepartment();

	@Override
	public CrmDepartment getModel() {
		return department;
	}

	private DepartmentService departmentService;

	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public String findAll() {
		List<CrmDepartment> allDep = departmentService.findAll();
		ActionContext.getContext().put("allDep", allDep);
		return "findAll";
	}

	/**
	 * 编辑操作
	 * @return
	 */
	public String addUI() {
		CrmDepartment findId = this.departmentService.findId(department.getDepId());
		ActionContext.getContext().getValueStack().push(findId);
		return "addUI";
	}
}
